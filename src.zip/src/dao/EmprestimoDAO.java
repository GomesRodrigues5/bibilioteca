package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import model.Emprestimo;

public class EmprestimoDAO {

    public void salvar(Emprestimo emprestimo) {
        String sql = "INSERT INTO Emprestimo (id_estudante, id_livro, data_de_emprestimo, hora_de_emprestimo, data_entrega, hora_de_entrega, valor, acao, data_e_hora_da_entrega, id_funcionario) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = ConexaoMySQL.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, emprestimo.getIdEstudante());
            stmt.setInt(2, emprestimo.getIdLivro());
            stmt.setDate(3, emprestimo.getDataDeEmprestimo());
            stmt.setTime(4, emprestimo.getHoraDeEmprestimo());
            stmt.setDate(5, emprestimo.getDataEntrega());
            stmt.setTime(6, emprestimo.getHoraDeEntrega());
            stmt.setDouble(7, emprestimo.getValor());
            stmt.setString(8, emprestimo.getAcao());
            if (emprestimo.getDataEHoraDaEntrega() != null) {
                stmt.setTimestamp(9, new Timestamp(emprestimo.getDataEHoraDaEntrega().getTime()));
            } else {
                stmt.setNull(9, Types.TIMESTAMP);
            }
            stmt.setInt(10, emprestimo.getIdFuncionario());
            stmt.executeUpdate();
            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    emprestimo.setIdEmprestimo(rs.getInt(1));
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar empréstimo: " + e.getMessage());
        }
    }

    public void atualizar(Emprestimo emprestimo) {
        String sql = "UPDATE Emprestimo SET id_estudante = ?, id_livro = ?, data_de_emprestimo = ?, hora_de_emprestimo = ?, data_entrega = ?, hora_de_entrega = ?, valor = ?, acao = ?, data_e_hora_da_entrega = ?, id_funcionario = ? WHERE id_emprestimo = ?";
        try (Connection conn = ConexaoMySQL.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, emprestimo.getIdEstudante());
            stmt.setInt(2, emprestimo.getIdLivro());
            stmt.setDate(3, emprestimo.getDataDeEmprestimo());
            stmt.setTime(4, emprestimo.getHoraDeEmprestimo());
            stmt.setDate(5, emprestimo.getDataEntrega());
            stmt.setTime(6, emprestimo.getHoraDeEntrega());
            stmt.setDouble(7, emprestimo.getValor());
            stmt.setString(8, emprestimo.getAcao());
            if (emprestimo.getDataEHoraDaEntrega() != null) {
                stmt.setTimestamp(9, new Timestamp(emprestimo.getDataEHoraDaEntrega().getTime()));
            } else {
                stmt.setNull(9, Types.TIMESTAMP);
            }
            stmt.setInt(10, emprestimo.getIdFuncionario());
            stmt.setInt(11, emprestimo.getIdEmprestimo());
            stmt.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar empréstimo: " + e.getMessage());
        }
    }

    public void deletar(int idEmprestimo) {
        String sql = "DELETE FROM Emprestimo WHERE id_emprestimo = ?";
        try (Connection conn = ConexaoMySQL.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idEmprestimo);
            stmt.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao deletar empréstimo: " + e.getMessage());
        }
    }

    public List<Emprestimo> listarTodos() {
        List<Emprestimo> emprestimos = new ArrayList<>();
        String sql = "SELECT id_emprestimo, id_estudante, id_livro, data_de_emprestimo, hora_de_emprestimo, data_entrega, hora_de_entrega, valor, acao, data_e_hora_da_entrega, id_funcionario FROM Emprestimo ORDER BY id_emprestimo DESC";
        try (Connection conn = ConexaoMySQL.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Emprestimo emprestimo = new Emprestimo();
                emprestimo.setIdEmprestimo(rs.getInt("id_emprestimo"));
                emprestimo.setIdEstudante(rs.getInt("id_estudante"));
                emprestimo.setIdLivro(rs.getInt("id_livro"));
                emprestimo.setDataDeEmprestimo(rs.getDate("data_de_emprestimo"));
                emprestimo.setHoraDeEmprestimo(rs.getTime("hora_de_emprestimo"));
                emprestimo.setDataEntrega(rs.getDate("data_entrega"));
                emprestimo.setHoraDeEntrega(rs.getTime("hora_de_entrega"));
                emprestimo.setValor(rs.getDouble("valor"));
                emprestimo.setAcao(rs.getString("acao"));
                Timestamp ts = rs.getTimestamp("data_e_hora_da_entrega");
                if (ts != null) {
                    emprestimo.setDataEHoraDaEntrega(new java.util.Date(ts.getTime()));
                }
                emprestimo.setIdFuncionario(rs.getInt("id_funcionario"));
                emprestimos.add(emprestimo);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao listar empréstimos: " + e.getMessage());
        }
        return emprestimos;
    }

    public Emprestimo buscarPorId(int idEmprestimo) {
        String sql = "SELECT id_emprestimo, id_estudante, id_livro, data_de_emprestimo, hora_de_emprestimo, data_entrega, hora_de_entrega, valor, acao, data_e_hora_da_entrega, id_funcionario FROM Emprestimo WHERE id_emprestimo = ?";
        try (Connection conn = ConexaoMySQL.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idEmprestimo);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Emprestimo emprestimo = new Emprestimo();
                    emprestimo.setIdEmprestimo(rs.getInt("id_emprestimo"));
                    emprestimo.setIdEstudante(rs.getInt("id_estudante"));
                    emprestimo.setIdLivro(rs.getInt("id_livro"));
                    emprestimo.setDataDeEmprestimo(rs.getDate("data_de_emprestimo"));
                    emprestimo.setHoraDeEmprestimo(rs.getTime("hora_de_emprestimo"));
                    emprestimo.setDataEntrega(rs.getDate("data_entrega"));
                    emprestimo.setHoraDeEntrega(rs.getTime("hora_de_entrega"));
                    emprestimo.setValor(rs.getDouble("valor"));
                    emprestimo.setAcao(rs.getString("acao"));
                    Timestamp ts = rs.getTimestamp("data_e_hora_da_entrega");
                    if (ts != null) {
                        emprestimo.setDataEHoraDaEntrega(new java.util.Date(ts.getTime()));
                    }
                    emprestimo.setIdFuncionario(rs.getInt("id_funcionario"));
                    return emprestimo;
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar empréstimo: " + e.getMessage());
        }
        return null;
    }
}
