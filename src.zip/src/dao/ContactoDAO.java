package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Contacto;

public class ContactoDAO {

    public void salvar(Contacto contacto) throws SQLException {
        String sql = "INSERT INTO Contacto (telefone1, telefone2) VALUES (?, ?)";
        try (Connection conn = ConexaoMySQL.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, contacto.getTelefone1());
            stmt.setString(2, contacto.getTelefone2());
            stmt.executeUpdate();
            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    contacto.setIdContacto(rs.getInt(1));
                }
            }
        }
    }

    public void atualizar(Contacto contacto) throws SQLException {
        String sql = "UPDATE Contacto SET telefone1 = ?, telefone2 = ? WHERE id_contacto = ?";
        try (Connection conn = ConexaoMySQL.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, contacto.getTelefone1());
            stmt.setString(2, contacto.getTelefone2());
            stmt.setInt(3, contacto.getIdContacto());
            stmt.executeUpdate();
        }
    }

    public void deletar(int idContacto) throws SQLException {
        String sql = "DELETE FROM Contacto WHERE id_contacto = ?";
        try (Connection conn = ConexaoMySQL.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idContacto);
            stmt.executeUpdate();
        }
    }

    public List<Contacto> listarTodos() throws SQLException {
        List<Contacto> contactos = new ArrayList<>();
        String sql = "SELECT id_contacto, telefone1, telefone2 FROM Contacto ORDER BY telefone1";
        try (Connection conn = ConexaoMySQL.getConnection(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Contacto contacto = new Contacto();
                contacto.setIdContacto(rs.getInt("id_contacto"));
                contacto.setTelefone1(rs.getString("telefone1"));
                contacto.setTelefone2(rs.getString("telefone2"));
                contactos.add(contacto);
            }
        }
        return contactos;
    }

    public Contacto buscarPorId(int idContacto) throws SQLException {
        String sql = "SELECT id_contacto, telefone1, telefone2 FROM Contacto WHERE id_contacto = ?";
        try (Connection conn = ConexaoMySQL.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idContacto);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Contacto contacto = new Contacto();
                    contacto.setIdContacto(rs.getInt("id_contacto"));
                    contacto.setTelefone1(rs.getString("telefone1"));
                    contacto.setTelefone2(rs.getString("telefone2"));
                    return contacto;
                }
            }
        }
        return null;
    }
}