package view;
/*BIBILHOTECAS PRINCIPAIS*/

import controller.EstudanteController;
import controller.FuncionarioController;
import dao.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.function.Consumer;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import model.*;
/*CLASSE TELA DO ADMINISTRADOR*/
public class TelaPrincipalAdmin extends JFrame {
    
    /*COMPONENTES GRAFICOS */
    private CardLayout cardLayout;
    private JPanel cardPanel;
    private JPanel menuPanel;
    private JPanel menuWrapper;
    private boolean menuVisible = true;
    private Timer animationTimer;
    private int currentWidth;
    private static final int MENU_WIDTH = 260;
    private static final int ANIMATION_DURATION = 300;
    private static final int FRAME_HEIGHT = 720;

    // Funcionário autenticado
    private Funcionario funcionarioAutenticado;

    private EstudanteController estudanteController = new EstudanteController();
    private FuncionarioController funcionarioController = new FuncionarioController();
    private FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
    private LivroDAO livroDAO = new LivroDAO();
    private ComputadorDAO computadorDAO = new ComputadorDAO();
    private ArmarioDAO armarioDAO = new ArmarioDAO();
    private CursoDAO cursoDAO = new CursoDAO();
    private DepartamentoDAO departamentoDAO = new DepartamentoDAO();
    private EnderecoDAO enderecoDAO = new EnderecoDAO();
    private ContactoDAO contactoDAO = new ContactoDAO();
    private FuncaoDAO funcaoDAO = new FuncaoDAO();
    private EmprestimoDAO emprestimoDAO = new EmprestimoDAO();

    private DefaultTableModel estudantesTableModel;
    private JTable estudantesTable;
    private DefaultTableModel emprestimosTableModel;
    private JTable emprestimosTable;
    private DefaultTableModel funcionariosTableModel;
    private JTable funcionariosTable;
    private DefaultTableModel livrosTableModel;
    private JTable livrosTable;
    private DefaultTableModel computadoresTableModel;
    private JTable computadoresTable;
    private DefaultTableModel armariosTableModel;
    private JTable armariosTable;
    private DefaultTableModel cursosTableModel;
    private JTable cursosTable;
    private DefaultTableModel departamentosTableModel;
    private JTable departamentosTable;
    private DefaultTableModel enderecosTableModel;
    private JTable enderecosTable;
    private DefaultTableModel contactosTableModel;
    private JTable contactosTable;
    private DefaultTableModel funcoesTableModel;
    private JTable funcoesTable;

    // Construtor com suporte a funcionário autenticado
    public TelaPrincipalAdmin(Funcionario funcionario) {
        this();
        this.funcionarioAutenticado = funcionario;
    }

    public TelaPrincipalAdmin() {
        setTitle("Admin - Sistema de Biblioteca");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        menuPanel = createMenuPanel();
        menuWrapper = new JPanel(new BorderLayout());
        menuWrapper.setPreferredSize(new Dimension(MENU_WIDTH, FRAME_HEIGHT));
        menuWrapper.add(createToggleHeader(), BorderLayout.NORTH);
        menuWrapper.add(menuPanel, BorderLayout.CENTER);
        add(menuWrapper, BorderLayout.WEST);

        cardPanel = new JPanel();
        cardLayout = new CardLayout();
        cardPanel.setLayout(cardLayout);
        cardPanel.add(createDashboardPanel(), "Inicio");
        cardPanel.add(createGerenciarEstudantesPanel(), "estudantes");
        cardPanel.add(createGerenciarFuncionariosPanel(), "funcionarios");
        cardPanel.add(createGerenciarLivrosPanel(), "livros");
        cardPanel.add(createGerenciarComputadoresPanel(), "computadores");
        cardPanel.add(createGerenciarArmariosPanel(), "armarios");
        cardPanel.add(createGerenciarCursosPanel(), "cursos");
        cardPanel.add(createGerenciarDepartamentosPanel(), "departamentos");
        cardPanel.add(createGerenciarEnderecosPanel(), "enderecos");
        cardPanel.add(createGerenciarContactosPanel(), "contactos");
        cardPanel.add(createGerenciarFuncoesPanel(), "funcoes");
        cardPanel.add(createGerenciarEmprestimosPanel(), "emprestimos");
        cardPanel.add(createGerenciarRelatoriosPanel(), "relatorios");

        add(cardPanel, BorderLayout.CENTER);

        cardLayout.show(cardPanel, "Inicio");
        setVisible(true);
    }

    private JPanel createMenuPanel() {
        JPanel menuPanel = new JPanel();
        menuPanel.setBackground(new Color(12, 32, 55));
        menuPanel.setLayout(new BoxLayout(menuPanel, BoxLayout.Y_AXIS));
        menuPanel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JLabel logoLabel = new JLabel();
        logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        ImageIcon logoIcon = loadIcon("src/view/img/logotipobranco.png", 90, 90);
        if (logoIcon != null) {
            logoLabel.setIcon(logoIcon);
        } 
        
        else 
        
        {
            logoLabel.setText("UÓR");
            logoLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
            logoLabel.setForeground(Color.WHITE);
        }
        menuPanel.add(logoLabel);

        JLabel title = new JLabel("Sistema Biblioteca");
        title.setFont(new Font("Segoe UI", Font.BOLD, 16));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setBorder(new EmptyBorder(10, 0, 30, 0));
        menuPanel.add(title);
        //ICONES DO MENU OPÇÃO DA TELAPRINCILA
        menuPanel.add(createMenuButton("Inicio", "inicio", "dashboard"));
        menuPanel.add(createMenuButton("Estudantes", "user", "estudantes"));
        menuPanel.add(createMenuButton("Funcionários", "funcionario", "funcionarios"));
        menuPanel.add(createMenuButton("Livros", "livro", "livros"));
        menuPanel.add(createMenuButton("Computadores", "computador", "computadores"));
        menuPanel.add(createMenuButton("Armários", "armario", "armarios"));
        menuPanel.add(createMenuButton("Cursos", "curso", "cursos"));
        menuPanel.add(createMenuButton("Departamentos", "departamentos", "departamentos"));
        menuPanel.add(createMenuButton("Endereços", "endereco", "enderecos"));
        menuPanel.add(createMenuButton("Contactos", "contacto", "contactos"));
        menuPanel.add(createMenuButton("Funções", "funcao", "funcoes"));
        menuPanel.add(createMenuButton("Empréstimos", "emprestar", "emprestimos"));
        menuPanel.add(createMenuButton("Atendimento", "atendimento", null));
        menuPanel.add(createMenuButton("Relatórios", "relatorio", "relatorios"));

        menuPanel.add(Box.createVerticalGlue());
        RoundedButton btnLogout = new RoundedButton("Sair", 24);
        btnLogout.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnLogout.setMaximumSize(new Dimension(Integer.MAX_VALUE, 45));
        btnLogout.setBackground(new Color(255, 140, 0));
        btnLogout.setForeground(Color.WHITE);
        btnLogout.setFocusPainted(false);
        btnLogout.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnLogout.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnLogout.setBorder(new LineBorder(new Color(255, 140, 0), 2, true));
        btnLogout.addActionListener(e -> {
            new TelaLogin();
            /*SAI DA TELA ADMIN  E CHAMA A TELALOGIN*/
            dispose();
        });
        menuPanel.add(btnLogout);

        return menuPanel;
    }

    private JPanel createToggleHeader() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(12, 32, 55));
        headerPanel.setBorder(new EmptyBorder(8, 12, 8, 12));

        JButton toggleButton = new JButton();
        toggleButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        toggleButton.setFocusPainted(false);
        toggleButton.setBackground(new Color(18, 46, 77));
        toggleButton.setForeground(Color.WHITE);
        toggleButton.setFont(new Font("Segoe UI", Font.BOLD, 18));
        toggleButton.setBorder(new LineBorder(new Color(59, 133, 193), 1, true));
        toggleButton.setPreferredSize(new Dimension(40, 32));
        toggleButton.setMargin(new Insets(0, 0, 0, 0));

        // Carregar ícone close para quando o menu estiver visível
        ImageIcon closeIcon = loadIcon("src/view/icon/close.png", 16, 16);
        if (closeIcon != null) {
            toggleButton.setIcon(closeIcon);
        }

        toggleButton.addActionListener(e -> {
            animateMenuToggle(toggleButton);
        });
        headerPanel.add(toggleButton, BorderLayout.EAST);

        return headerPanel;
    }

    private void animateMenuToggle(JButton toggleButton) {
        if (animationTimer != null && animationTimer.isRunning()) {
            return;
        }

        final long startTime = System.currentTimeMillis();
        final int startWidth = menuWrapper.getWidth();
        final int targetWidth = menuVisible ? 50 : MENU_WIDTH;

        animationTimer = new Timer(16, e -> {
            long elapsed = System.currentTimeMillis() - startTime;
            if (elapsed >= ANIMATION_DURATION) {
                animationTimer.stop();
                menuVisible = !menuVisible;
                menuPanel.setVisible(menuVisible);
                menuWrapper.setPreferredSize(new Dimension(targetWidth, FRAME_HEIGHT));

                // Trocar ícones baseado no estado do menu
                if (menuVisible) {
                    ImageIcon closeIcon = loadIcon("src/view/icon/close.png", 16, 16);
                    toggleButton.setIcon(closeIcon);
                } else {
                    ImageIcon menuIcon = loadIcon("src/view/icon/menu.png", 16, 16);
                    toggleButton.setIcon(menuIcon);
                }

                revalidate();
                repaint();
            } else {
                float progress = (float) elapsed / ANIMATION_DURATION;
                int newWidth = (int) (startWidth + (targetWidth - startWidth) * progress);
                menuWrapper.setPreferredSize(new Dimension(newWidth, FRAME_HEIGHT));
                
                if (menuVisible) {
                    menuPanel.setVisible(true);
                    menuPanel.setOpaque(true);
                } else if (elapsed > ANIMATION_DURATION / 2) {
                    menuPanel.setVisible(false);
                }
                
                revalidate();
                repaint();
            }
        });
        animationTimer.start();
    }

    private JButton createMenuButton(String text, String iconKey, String cardName) {
        JButton button = new JButton(text);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setBackground(new Color(18, 46, 77));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(25, 102, 153), 1, true),
            new EmptyBorder(8, 12, 8, 12)
        ));
        button.setIconTextGap(12);

        String iconPath = "src/view/icon/" + iconKey + ".png";
        ImageIcon icon = loadIcon(iconPath, 24, 24);
        if (icon == null) {
            icon = loadIcon("src/view/img/logotipo.png", 24, 24);
        }
        if (icon != null) {
            button.setIcon(icon);
        }
        if (cardName != null) {
            button.addActionListener(e -> cardLayout.show(cardPanel, cardName));
        } else {
            button.addActionListener(e -> new TelaAtendimento(TelaPrincipalAdmin.this));
        }
        return button;
    }

    private JPanel createGerenciarEstudantesPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 248, 252));
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        // Painel superior com título e botão adicionar no canto direito
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);
        JLabel title = new JLabel("Gerenciar Estudantes");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(new Color(30, 40, 55));
        title.setBorder(new EmptyBorder(20, 0, 10, 0));
        topPanel.add(title, BorderLayout.WEST);

        JButton btnAdicionar = createPrimaryButton("Adicionar Estudante");
        btnAdicionar.addActionListener(e -> showAdicionarEstudanteModal());
        topPanel.add(btnAdicionar, BorderLayout.EAST);
        panel.add(topPanel, BorderLayout.NORTH);

        // Tabela de estudantes
        String[] columnNames = {"ID", "ESTUDANTE", "NÚMERO", "CURSO", "DEPARTAMENTO", "CONTACTO", "ACÇÃO"};
        this.estudantesTableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 6; // Apenas coluna ACÇÃO é editável
            }
        };

        estudantesTable = new JTable(estudantesTableModel);
        estudantesTable.setRowHeight(35);
        estudantesTable.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        estudantesTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        estudantesTable.getTableHeader().setBackground(new Color(240, 245, 250));
        estudantesTable.getTableHeader().setForeground(new Color(30, 40, 55));
        estudantesTable.setSelectionBackground(new Color(220, 235, 255));
        estudantesTable.setGridColor(new Color(200, 210, 220));

        // Configurar coluna ACÇÃO com botões
        estudantesTable.getColumnModel().getColumn(6).setCellRenderer(new ButtonRenderer());
        estudantesTable.getColumnModel().getColumn(6).setCellEditor(new ButtonEditor(new JCheckBox(), estudantesTable, this::deleteEstudanteRow, this::viewEstudanteRow, this::editEstudanteRow));

        carregarEstudantes();

        JScrollPane scrollPane = new JScrollPane(estudantesTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 210, 220), 1));
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private void showAdicionarEstudanteModal() {
        JDialog dialog = new JDialog(this, "Adicionar Estudante", true);
        dialog.setSize(500, 520);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        // Logo
        JLabel logoLabel = new JLabel();
        logoLabel.setHorizontalAlignment(SwingConstants.CENTER);
        ImageIcon verificarLogo = loadIcon("src/view/img/verificar.png", 80, 80);
        if (verificarLogo != null) {
            logoLabel.setIcon(verificarLogo);
        } else {
            logoLabel.setText("ADICIONAR");
            logoLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
            logoLabel.setForeground(new Color(30, 40, 55));
        }

        // Campos do formulário
        JTextField txtNome = new JTextField();
        JTextField txtNumero = new JTextField();
        JComboBox<EstudanteDAO.CursoItem> comboCurso = new JComboBox<>();
        JTextField txtDepartamento = new JTextField();
        JComboBox<EstudanteDAO.ContactoItem> comboContacto = new JComboBox<>();
        JComboBox<EstudanteDAO.EnderecoItem> comboEndereco = new JComboBox<>();

        ((AbstractDocument) txtNome.getDocument()).setDocumentFilter(new LetterOnlyFilter());
        ((AbstractDocument) txtNumero.getDocument()).setDocumentFilter(new DigitOnlyFilter());
        ((AbstractDocument) txtDepartamento.getDocument()).setDocumentFilter(new LetterOnlyFilter());

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        formPanel.setBorder(new EmptyBorder(20, 20, 20, 20));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 0, 8, 0);
        gbc.weightx = 1.0;

        gbc.gridy = 0;
        formPanel.add(createLabeledFieldPanel("Nome", "src/view/icon/user.png", txtNome, 300, 50), gbc);

        gbc.gridy = 1;
        formPanel.add(createLabeledFieldPanel("Número", "src/view/icon/user.png", txtNumero, 300, 50), gbc);

        List<EstudanteDAO.CursoItem> cursos = carregarCursos();
        if (cursos.isEmpty()) {
            comboCurso.addItem(new EstudanteDAO.CursoItem(0, "Nenhum curso cadastrado"));
            comboCurso.setEnabled(false);
        } else {
            for (EstudanteDAO.CursoItem cursoItem : cursos) {
                comboCurso.addItem(cursoItem);
            }
        }

        gbc.gridy = 2;
        formPanel.add(createLabeledComboPanel("Curso", "src/view/icon/user.png", comboCurso, 300, 50), gbc);

        gbc.gridy = 3;
        formPanel.add(createLabeledFieldPanel("Departamento", "src/view/icon/user.png", txtDepartamento, 300, 50), gbc);

        List<EstudanteDAO.ContactoItem> contactos = carregarContactosEstudante();
        if (contactos.isEmpty()) {
            comboContacto.addItem(new EstudanteDAO.ContactoItem(0, "Sem telefone", null));
            comboContacto.setEnabled(false);
        } else {
            for (EstudanteDAO.ContactoItem contactoItem : contactos) {
                comboContacto.addItem(contactoItem);
            }
        }
        gbc.gridy = 4;
        formPanel.add(createLabeledComboPanel("Contacto", "src/view/icon/user.png", comboContacto, 300, 50), gbc);

        List<EstudanteDAO.EnderecoItem> enderecos = carregarEnderecosEstudante();
        if (enderecos.isEmpty()) {
            comboEndereco.addItem(new EstudanteDAO.EnderecoItem(0, "Sem endereço", ""));
            comboEndereco.setEnabled(false);
        } else {
            for (EstudanteDAO.EnderecoItem enderecoItem : enderecos) {
                comboEndereco.addItem(enderecoItem);
            }
        }
        gbc.gridy = 5;
        formPanel.add(createLabeledComboPanel("Endereço", "src/view/icon/user.png", comboEndereco, 300, 50), gbc);

        // Botões
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.setBorder(new EmptyBorder(30, 20, 20, 20));

        JButton btnSalvar = new RoundedButton("SALVAR", 24);
        btnSalvar.setPreferredSize(new Dimension(140, 45));
        btnSalvar.setMargin(new Insets(8, 16, 8, 16));
        btnSalvar.setBackground(new Color(34, 197, 94));
        btnSalvar.setForeground(Color.WHITE);
        btnSalvar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnSalvar.setBorder(new LineBorder(new Color(34, 197, 94), 2, true));
        btnSalvar.addActionListener(e -> {
            String nome = getFieldValue(txtNome, "Nome");
            String numero = getFieldValue(txtNumero, "Número");
            EstudanteDAO.CursoItem cursoSelecionado = (EstudanteDAO.CursoItem) comboCurso.getSelectedItem();
            String departamento = getFieldValue(txtDepartamento, "Departamento");
            EstudanteDAO.ContactoItem contactoSelecionado = (EstudanteDAO.ContactoItem) comboContacto.getSelectedItem();
            EstudanteDAO.EnderecoItem enderecoSelecionado = (EstudanteDAO.EnderecoItem) comboEndereco.getSelectedItem();

            if (nome.isEmpty() || numero.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Preencha o nome e o número do estudante.", "Atenção", JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (cursoSelecionado == null || cursoSelecionado.getId() == 0) {
                JOptionPane.showMessageDialog(dialog, "Selecione um curso válido.", "Atenção", JOptionPane.WARNING_MESSAGE);
                return;
            }

            Estudante estudante = new Estudante();
            estudante.setNome(nome);
            estudante.setNumeroEstudante(numero);
            estudante.setIdCurso(cursoSelecionado.getId());
            estudante.setCurso(cursoSelecionado.getNome());
            estudante.setDepartamento(departamento);
            estudante.setIdContacto(contactoSelecionado != null ? contactoSelecionado.getId() : 0);
            estudante.setContacto(contactoSelecionado != null ? contactoSelecionado.toString() : "");
            estudante.setIdEndereco(enderecoSelecionado != null ? enderecoSelecionado.getId() : 0);
            estudante.setEmail(null);

            try {
                estudanteController.salvarEstudante(estudante);
                carregarEstudantes();
                JOptionPane.showMessageDialog(dialog, "Estudante salvo com sucesso!");
                dialog.dispose();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(dialog, "Erro ao salvar estudante: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });

        JButton btnCancelar = new RoundedButton("CANCELAR", 24);
        btnCancelar.setPreferredSize(new Dimension(140, 45));
        btnCancelar.setMargin(new Insets(8, 16, 8, 16));
        btnCancelar.setBackground(new Color(220, 53, 69));
        btnCancelar.setForeground(Color.WHITE);
        btnCancelar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnCancelar.setBorder(new LineBorder(new Color(220, 53, 69), 2, true));
        btnCancelar.addActionListener(e -> dialog.dispose());

        buttonPanel.add(btnSalvar);
        buttonPanel.add(btnCancelar);

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);
        topPanel.setBorder(new EmptyBorder(12, 12, 12, 12));
        topPanel.add(logoLabel, BorderLayout.WEST);

        dialog.add(topPanel, BorderLayout.NORTH);
        dialog.add(formPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);

        dialog.setVisible(true);
    }

    private void carregarEstudantes() {
        if (estudantesTableModel == null) {
            return;
        }

        estudantesTableModel.setRowCount(0);
        try {
            List<Estudante> estudantes = estudanteController.listarEstudantes();
            for (Estudante estudante : estudantes) {
                estudantesTableModel.addRow(new Object[]{
                    estudante.getIdEstudante(),
                    estudante.getNome(),
                    estudante.getNumeroEstudante(),
                    estudante.getCurso(),
                    estudante.getDepartamento(),
                    estudante.getContacto(),
                    "Ações"
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar estudantes: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private List<EstudanteDAO.CursoItem> carregarCursos() {
        try {
            return estudanteController.listarCursos();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar cursos: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            return new java.util.ArrayList<>();
        }
    }

    private void deleteEstudanteRow(int row) {
        if (row < 0 || estudantesTableModel == null) {
            return;
        }

        int resposta = JOptionPane.showConfirmDialog(this,
                "Deseja realmente deletar este estudante?",
                "Confirmar", JOptionPane.YES_NO_OPTION);

        if (resposta != JOptionPane.YES_OPTION) {
            return;
        }

        int idEstudante = Integer.parseInt(estudantesTableModel.getValueAt(row, 0).toString());
        try {
            estudanteController.deletarEstudante(idEstudante);
            estudantesTableModel.removeRow(row);
            JOptionPane.showMessageDialog(this, "Estudante deletado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao deletar estudante: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void viewEstudanteRow(int row) {
        if (row < 0 || estudantesTableModel == null) {
            return;
        }
        String nome = estudantesTableModel.getValueAt(row, 1).toString();
        String numero = estudantesTableModel.getValueAt(row, 2).toString();
        String curso = estudantesTableModel.getValueAt(row, 3).toString();
        String departamento = estudantesTableModel.getValueAt(row, 4).toString();
        String contacto = estudantesTableModel.getValueAt(row, 5).toString();
        JOptionPane.showMessageDialog(this,
                "Nome: " + nome + "\nNúmero: " + numero + "\nCurso: " + curso + "\nDepartamento: " + departamento + "\nContacto: " + contacto,
                "Detalhes do Estudante", JOptionPane.INFORMATION_MESSAGE);
    }

    private void editEstudanteRow(int row) {
        if (row < 0 || estudantesTableModel == null) {
            return;
        }
        int idEstudante = Integer.parseInt(estudantesTableModel.getValueAt(row, 0).toString());
        Estudante estudante = estudanteController.buscarPorId(idEstudante);
        if (estudante == null) {
            JOptionPane.showMessageDialog(this, "Estudante não encontrado para edição.", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }
        showEditarEstudanteModal(estudante);
    }

    private void showEditarEstudanteModal(Estudante estudante) {
        JDialog dialog = new JDialog(this, "Editar Estudante", true);
        dialog.setSize(520, 580);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        JLabel logoLabel = new JLabel();
        logoLabel.setHorizontalAlignment(SwingConstants.CENTER);
        ImageIcon verificarLogo = loadIcon("src/view/img/verificar.png", 80, 80);
        if (verificarLogo != null) {
            logoLabel.setIcon(verificarLogo);
        } else {
            logoLabel.setText("EDITAR ESTUDANTE");
            logoLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
            logoLabel.setForeground(new Color(30, 40, 55));
        }

        JTextField txtNome = new JTextField(estudante.getNome());
        JTextField txtNumero = new JTextField(estudante.getNumeroEstudante());
        JComboBox<EstudanteDAO.CursoItem> comboCurso = new JComboBox<>();
        JComboBox<EstudanteDAO.ContactoItem> comboContacto = new JComboBox<>();
        JComboBox<EstudanteDAO.EnderecoItem> comboEndereco = new JComboBox<>();

        ((AbstractDocument) txtNome.getDocument()).setDocumentFilter(new LetterOnlyFilter());
        ((AbstractDocument) txtNumero.getDocument()).setDocumentFilter(new DigitOnlyFilter());

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        formPanel.setBorder(new EmptyBorder(20, 20, 20, 20));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 0, 8, 0);
        gbc.weightx = 1.0;

        gbc.gridy = 0;
        formPanel.add(createLabeledFieldPanel("Nome", "src/view/icon/user.png", txtNome, 300, 50), gbc);

        gbc.gridy = 1;
        formPanel.add(createLabeledFieldPanel("Número", "src/view/icon/user.png", txtNumero, 300, 50), gbc);

        List<EstudanteDAO.CursoItem> cursos = carregarCursos();
        if (cursos.isEmpty()) {
            comboCurso.addItem(new EstudanteDAO.CursoItem(0, "Nenhum curso cadastrado"));
            comboCurso.setEnabled(false);
        } else {
            for (EstudanteDAO.CursoItem curso : cursos) {
                comboCurso.addItem(curso);
                if (curso.getId() == estudante.getIdCurso()) {
                    comboCurso.setSelectedItem(curso);
                }
            }
        }
        gbc.gridy = 2;
        formPanel.add(createLabeledComboPanel("Curso", "src/view/icon/user.png", comboCurso, 300, 50), gbc);

        List<EstudanteDAO.ContactoItem> contactos = carregarContactosEstudante();
        if (contactos.isEmpty()) {
            comboContacto.addItem(new EstudanteDAO.ContactoItem(0, "Sem telefone", null));
            comboContacto.setEnabled(false);
        } else {
            for (EstudanteDAO.ContactoItem contacto : contactos) {
                comboContacto.addItem(contacto);
                if (contacto.getId() == estudante.getIdContacto()) {
                    comboContacto.setSelectedItem(contacto);
                }
            }
        }
        gbc.gridy = 3;
        formPanel.add(createLabeledComboPanel("Telefone", "src/view/icon/user.png", comboContacto, 300, 50), gbc);

        List<EstudanteDAO.EnderecoItem> enderecos = carregarEnderecosEstudante();
        if (enderecos.isEmpty()) {
            comboEndereco.addItem(new EstudanteDAO.EnderecoItem(0, "Sem endereço", ""));
            comboEndereco.setEnabled(false);
        } else {
            for (EstudanteDAO.EnderecoItem endereco : enderecos) {
                comboEndereco.addItem(endereco);
                if (endereco.getId() == estudante.getIdEndereco()) {
                    comboEndereco.setSelectedItem(endereco);
                }
            }
        }
        gbc.gridy = 4;
        formPanel.add(createLabeledComboPanel("Endereço", "src/view/icon/user.png", comboEndereco, 300, 50), gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.setBorder(new EmptyBorder(30, 20, 20, 20));

        JButton btnSalvar = new RoundedButton("SALVAR ALTERAÇÃO", 24);
        btnSalvar.setPreferredSize(new Dimension(180, 45));
        btnSalvar.setBackground(new Color(34, 197, 94));
        btnSalvar.setForeground(Color.WHITE);
        btnSalvar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnSalvar.setBorder(new LineBorder(new Color(34, 197, 94), 2, true));
        btnSalvar.addActionListener(e -> {
            String nome = getFieldValue(txtNome, "Nome");
            String numero = getFieldValue(txtNumero, "Número");
            EstudanteDAO.CursoItem cursoSelecionado = (EstudanteDAO.CursoItem) comboCurso.getSelectedItem();
            EstudanteDAO.ContactoItem contactoSelecionado = (EstudanteDAO.ContactoItem) comboContacto.getSelectedItem();
            EstudanteDAO.EnderecoItem enderecoSelecionado = (EstudanteDAO.EnderecoItem) comboEndereco.getSelectedItem();

            if (nome.isEmpty() || numero.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Preencha o nome e o número do estudante.", "Atenção", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (cursoSelecionado == null || cursoSelecionado.getId() == 0) {
                JOptionPane.showMessageDialog(dialog, "Selecione um curso válido.", "Atenção", JOptionPane.WARNING_MESSAGE);
                return;
            }

            estudante.setNome(nome);
            estudante.setNumeroEstudante(numero);
            estudante.setIdCurso(cursoSelecionado.getId());
            estudante.setCurso(cursoSelecionado.getNome());
            estudante.setIdContacto(contactoSelecionado != null ? contactoSelecionado.getId() : 0);
            estudante.setContacto(contactoSelecionado != null ? contactoSelecionado.toString() : "");
            estudante.setIdEndereco(enderecoSelecionado != null ? enderecoSelecionado.getId() : 0);

            try {
                estudanteController.atualizarEstudante(estudante);
                carregarEstudantes();
                JOptionPane.showMessageDialog(dialog, "Estudante atualizado com sucesso!");
                dialog.dispose();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(dialog, "Erro ao salvar alterações: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });

        JButton btnCancelar = new RoundedButton("CANCELAR", 24);
        btnCancelar.setPreferredSize(new Dimension(140, 45));
        btnCancelar.setBackground(new Color(220, 53, 69));
        btnCancelar.setForeground(Color.WHITE);
        btnCancelar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnCancelar.setBorder(new LineBorder(new Color(220, 53, 69), 2, true));
        btnCancelar.addActionListener(e -> dialog.dispose());

        buttonPanel.add(btnSalvar);
        buttonPanel.add(btnCancelar);

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);
        topPanel.setBorder(new EmptyBorder(12, 12, 12, 12));
        topPanel.add(logoLabel, BorderLayout.WEST);

        dialog.add(topPanel, BorderLayout.NORTH);
        dialog.add(formPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private List<EstudanteDAO.ContactoItem> carregarContactosEstudante() {
        try {
            return estudanteController.listarContactos();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar contactos: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            return new java.util.ArrayList<>();
        }
    }

    private List<EstudanteDAO.EnderecoItem> carregarEnderecosEstudante() {
        try {
            return estudanteController.listarEnderecos();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar endereços: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            return new java.util.ArrayList<>();
        }
    }

    private String getFieldValue(JTextField field, String placeholder) {
        String value = field.getText();
        if (value == null || value.trim().isEmpty() || value.equals(placeholder)) {
            return "";
        }
        return value.trim();
    }

    private JPanel createGerenciarFuncionariosPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 248, 252));
        JLabel title = new JLabel("Gerenciar Funcionários");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(new Color(30, 40, 55));
        title.setBorder(new EmptyBorder(20, 20, 10, 20));
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);
        topPanel.add(title, BorderLayout.WEST);
        JButton btnNovo = createPrimaryButton("Adicionar Funcionário");
        btnNovo.addActionListener(e -> showAdicionarFuncionarioModal(null));
        topPanel.add(btnNovo, BorderLayout.EAST);
        panel.add(topPanel, BorderLayout.NORTH);

        funcionariosTableModel = new DefaultTableModel(new Object[]{"ID", "Nome", "Cargo", "Contacto", "Ações"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 4;
            }
        };
        funcionariosTable = new JTable(funcionariosTableModel);
        funcionariosTable.setRowHeight(40);
        funcionariosTable.getColumnModel().getColumn(4).setCellRenderer(new ButtonRenderer());
        funcionariosTable.getColumnModel().getColumn(4).setCellEditor(new ButtonEditor(new JCheckBox(), funcionariosTable, this::deleteFuncionarioRow, this::viewFuncionarioRow, this::editFuncionarioRow));
        panel.add(new JScrollPane(funcionariosTable), BorderLayout.CENTER);

        carregarFuncionarios();
        return panel;
    }

    private JPanel createGerenciarLivrosPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 248, 252));
        JLabel title = new JLabel("Gerenciar Livros");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(new Color(30, 40, 55));
        title.setBorder(new EmptyBorder(20, 20, 10, 20));
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);
        topPanel.add(title, BorderLayout.WEST);
        JButton btnNovo = createPrimaryButton("Adicionar Livro");
        btnNovo.addActionListener(e -> showAdicionarLivroModal(null));
        topPanel.add(btnNovo, BorderLayout.EAST);
        panel.add(topPanel, BorderLayout.NORTH);

        livrosTableModel = new DefaultTableModel(new Object[]{"ID", "Título", "Cor", "Código", "Armário", "Ações"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 5;
            }
        };
        livrosTable = new JTable(livrosTableModel);
        livrosTable.setRowHeight(40);
        livrosTable.getColumnModel().getColumn(5).setCellRenderer(new ButtonRenderer());
        livrosTable.getColumnModel().getColumn(5).setCellEditor(new ButtonEditor(new JCheckBox(), livrosTable, this::deleteLivroRow, this::viewLivroRow, this::editLivroRow));
        panel.add(new JScrollPane(livrosTable), BorderLayout.CENTER);

        carregarLivros();
        return panel;
    }

    private JPanel createGerenciarComputadoresPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 248, 252));
        JLabel title = new JLabel("Gerenciar Computadores");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(new Color(30, 40, 55));
        title.setBorder(new EmptyBorder(20, 20, 10, 20));
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);
        topPanel.add(title, BorderLayout.WEST);
        JButton btnNovo = createPrimaryButton("Adicionar Computador");
        btnNovo.addActionListener(e -> showAdicionarComputadorModal(null));
        topPanel.add(btnNovo, BorderLayout.EAST);
        panel.add(topPanel, BorderLayout.NORTH);

        computadoresTableModel = new DefaultTableModel(new Object[]{"ID", "Marca", "Modelo", "Status", "Ações"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 4;
            }
        };
        computadoresTable = new JTable(computadoresTableModel);
        computadoresTable.setRowHeight(40);
        computadoresTable.getColumnModel().getColumn(4).setCellRenderer(new ButtonRenderer());
        computadoresTable.getColumnModel().getColumn(4).setCellEditor(new ButtonEditor(new JCheckBox(), computadoresTable, this::deleteComputadorRow, this::viewComputadorRow, this::editComputadorRow));
        panel.add(new JScrollPane(computadoresTable), BorderLayout.CENTER);

        carregarComputadores();
        return panel;
    }

    private JPanel createGerenciarArmariosPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 248, 252));
        JLabel title = new JLabel("Gerenciar Armários");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(new Color(30, 40, 55));
        title.setBorder(new EmptyBorder(20, 20, 10, 20));
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);
        topPanel.add(title, BorderLayout.WEST);
        JButton btnNovo = createPrimaryButton("Adicionar Armário");
        btnNovo.addActionListener(e -> showAdicionarArmarioModal(null));
        topPanel.add(btnNovo, BorderLayout.EAST);
        panel.add(topPanel, BorderLayout.NORTH);

        armariosTableModel = new DefaultTableModel(new Object[]{"ID", "Armário", "Ações"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 2;
            }
        };
        armariosTable = new JTable(armariosTableModel);
        armariosTable.setRowHeight(40);
        armariosTable.getColumnModel().getColumn(2).setCellRenderer(new ButtonRenderer());
        armariosTable.getColumnModel().getColumn(2).setCellEditor(new ButtonEditor(new JCheckBox(), armariosTable, this::deleteArmarioRow, this::viewArmarioRow, this::editArmarioRow));
        panel.add(new JScrollPane(armariosTable), BorderLayout.CENTER);

        carregarArmarios();
        return panel;
    }

    private JPanel createGerenciarCursosPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 248, 252));
        JLabel title = new JLabel("Gerenciar Cursos");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(new Color(30, 40, 55));
        title.setBorder(new EmptyBorder(20, 20, 10, 20));
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);
        topPanel.add(title, BorderLayout.WEST);
        JButton btnNovo = createPrimaryButton("Adicionar Curso");
        btnNovo.addActionListener(e -> showAdicionarCursoModal(null));
        topPanel.add(btnNovo, BorderLayout.EAST);
        panel.add(topPanel, BorderLayout.NORTH);

        cursosTableModel = new DefaultTableModel(new Object[]{"ID", "Curso", "Departamento", "Ações"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 3;
            }
        };
        cursosTable = new JTable(cursosTableModel);
        cursosTable.setRowHeight(40);
        cursosTable.getColumnModel().getColumn(3).setCellRenderer(new ButtonRenderer());
        cursosTable.getColumnModel().getColumn(3).setCellEditor(new ButtonEditor(new JCheckBox(), cursosTable, this::deleteCursoRow, this::viewCursoRow, this::editCursoRow));
        panel.add(new JScrollPane(cursosTable), BorderLayout.CENTER);

        carregarCursosTabela();
        return panel;
    }

    private JPanel createGerenciarDepartamentosPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 248, 252));
        JLabel title = new JLabel("Gerenciar Departamentos");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(new Color(30, 40, 55));
        title.setBorder(new EmptyBorder(20, 20, 10, 20));
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);
        topPanel.add(title, BorderLayout.WEST);
        JButton btnNovo = createPrimaryButton("Adicionar Departamento");
        btnNovo.addActionListener(e -> showAdicionarDepartamentoModal(null));
        topPanel.add(btnNovo, BorderLayout.EAST);
        panel.add(topPanel, BorderLayout.NORTH);

        departamentosTableModel = new DefaultTableModel(new Object[]{"ID", "Departamento", "Ações"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 2;
            }
        };
        departamentosTable = new JTable(departamentosTableModel);
        departamentosTable.setRowHeight(40);
        departamentosTable.getColumnModel().getColumn(2).setCellRenderer(new ButtonRenderer());
        departamentosTable.getColumnModel().getColumn(2).setCellEditor(new ButtonEditor(new JCheckBox(), departamentosTable, this::deleteDepartamentoRow, this::viewDepartamentoRow, this::editDepartamentoRow));
        panel.add(new JScrollPane(departamentosTable), BorderLayout.CENTER);

        carregarDepartamentos();
        return panel;
    }

    private JPanel createGerenciarEnderecosPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 248, 252));
        JLabel title = new JLabel("Gerenciar Endereços");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(new Color(30, 40, 55));
        title.setBorder(new EmptyBorder(20, 20, 10, 20));

        enderecosTableModel = new DefaultTableModel(new Object[]{"ID", "Município", "Bairro", "Ações"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 3;
            }
        };
        enderecosTable = new JTable(enderecosTableModel);
        enderecosTable.setRowHeight(40);
        enderecosTable.getColumnModel().getColumn(3).setCellRenderer(new ButtonRenderer());
        enderecosTable.getColumnModel().getColumn(3).setCellEditor(new ButtonEditor(new JCheckBox(), enderecosTable, this::deleteEnderecoRow, this::viewEnderecoRow, this::editEnderecoRow));
        panel.add(new JScrollPane(enderecosTable), BorderLayout.CENTER);

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);
        topPanel.add(title, BorderLayout.WEST);
        JButton btnNovo = createPrimaryButton("Adicionar Endereço");
        btnNovo.addActionListener(e -> showAdicionarEnderecoModal(null));
        topPanel.add(btnNovo, BorderLayout.EAST);
        panel.add(topPanel, BorderLayout.NORTH);

        carregarEnderecos();
        return panel;
    }

    private JPanel createGerenciarContactosPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 248, 252));
        JLabel title = new JLabel("Gerenciar Contactos");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(new Color(30, 40, 55));
        title.setBorder(new EmptyBorder(20, 20, 10, 20));

        contactosTableModel = new DefaultTableModel(new Object[]{"ID", "Telefone 1", "Telefone 2", "Ações"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 3;
            }
        };
        contactosTable = new JTable(contactosTableModel);
        contactosTable.setRowHeight(40);
        contactosTable.getColumnModel().getColumn(3).setCellRenderer(new ButtonRenderer());
        contactosTable.getColumnModel().getColumn(3).setCellEditor(new ButtonEditor(new JCheckBox(), contactosTable, this::deleteContactoRow, this::viewContactoRow, this::editContactoRow));
        panel.add(new JScrollPane(contactosTable), BorderLayout.CENTER);

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);
        topPanel.add(title, BorderLayout.WEST);
        JButton btnNovo = createPrimaryButton("Adicionar Contacto");
        btnNovo.addActionListener(e -> showAdicionarContactoModal(null));
        topPanel.add(btnNovo, BorderLayout.EAST);
        panel.add(topPanel, BorderLayout.NORTH);

        carregarContactos();
        return panel;
    }

    private JPanel createGerenciarFuncoesPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 248, 252));
        JLabel title = new JLabel("Gerenciar Funções");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(new Color(30, 40, 55));
        title.setBorder(new EmptyBorder(20, 20, 10, 20));

        funcoesTableModel = new DefaultTableModel(new Object[]{"ID", "Função", "Descrição", "Ações"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 3;
            }
        };
        funcoesTable = new JTable(funcoesTableModel);
        funcoesTable.setRowHeight(40);
        funcoesTable.getColumnModel().getColumn(3).setCellRenderer(new ButtonRenderer());
        funcoesTable.getColumnModel().getColumn(3).setCellEditor(new ButtonEditor(new JCheckBox(), funcoesTable, this::deleteFuncaoRow, this::viewFuncaoRow, this::editFuncaoRow));
        panel.add(new JScrollPane(funcoesTable), BorderLayout.CENTER);

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);
        topPanel.add(title, BorderLayout.WEST);
        JButton btnNovo = createPrimaryButton("Adicionar Função");
        btnNovo.addActionListener(e -> showAdicionarFuncaoModal(null));
        topPanel.add(btnNovo, BorderLayout.EAST);
        panel.add(topPanel, BorderLayout.NORTH);

        carregarFuncoes();
        return panel;
    }

    private void carregarEnderecos() {
        enderecosTableModel.setRowCount(0);
        try {
            List<Endereco> enderecos = enderecoDAO.listarTodos();
            for (Endereco endereco : enderecos) {
                enderecosTableModel.addRow(new Object[]{
                    endereco.getIdEndereco(),
                    endereco.getMunicipio(),
                    endereco.getBairro(),
                    "Ações"
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar endereços: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarContactos() {
        contactosTableModel.setRowCount(0);
        try {
            List<Contacto> contactos = contactoDAO.listarTodos();
            for (Contacto contacto : contactos) {
                contactosTableModel.addRow(new Object[]{
                    contacto.getIdContacto(),
                    contacto.getTelefone1(),
                    contacto.getTelefone2(),
                    "Ações"
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar contactos: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarFuncoes() {
        funcoesTableModel.setRowCount(0);
        try {
            List<Funcao> funcoes = funcaoDAO.listarTodos();
            for (Funcao funcao : funcoes) {
                funcoesTableModel.addRow(new Object[]{
                    funcao.getIdFuncao(),
                    funcao.getFuncao(),
                    funcao.getDescricao(),
                    "Ações"
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar funções: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void showAdicionarEnderecoModal(Endereco endereco) {
        JDialog dialog = createModalDialog(endereco == null ? "Adicionar Endereço" : "Editar Endereço");
        JLabel logoLabel = new JLabel();
        ImageIcon verificarLogo = loadIcon("src/view/img/verificar.png", 80, 80);
        if (verificarLogo != null) {
            logoLabel.setIcon(verificarLogo);
        } else {
            logoLabel.setText(endereco == null ? "ADICIONAR" : "EDITAR");
            logoLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
            logoLabel.setForeground(new Color(30, 40, 55));
        }

        JTextField txtMunicipio = new JTextField(endereco != null ? endereco.getMunicipio() : "");
        JTextField txtBairro = new JTextField(endereco != null ? endereco.getBairro() : "");
        ((AbstractDocument) txtMunicipio.getDocument()).setDocumentFilter(new LetterOnlyFilter());
        ((AbstractDocument) txtBairro.getDocument()).setDocumentFilter(new LetterOnlyFilter());

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        formPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 0, 8, 0);
        gbc.weightx = 1.0;

        gbc.gridy = 0;
        formPanel.add(createLabeledFieldPanel("Município", "src/view/icon/localizacao.png", txtMunicipio, 300, 50), gbc);
        gbc.gridy = 1;
        formPanel.add(createLabeledFieldPanel("Bairro", "src/view/icon/localizacao.png", txtBairro, 300, 50), gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.setBorder(new EmptyBorder(30, 20, 20, 20));

        JButton btnSalvar = new RoundedButton(endereco == null ? "SALVAR" : "SALVAR ALTERAÇÃO", 24);
        styleActionButton(btnSalvar, new Color(34, 197, 94));
        btnSalvar.addActionListener(e -> {
            String municipio = getFieldValue(txtMunicipio, "Município");
            String bairro = getFieldValue(txtBairro, "Bairro");
            if (municipio.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Preencha o município.", "Atenção", JOptionPane.WARNING_MESSAGE);
                return;
            }
            Endereco atual = endereco != null ? endereco : new Endereco();
            atual.setMunicipio(municipio);
            atual.setBairro(bairro);
            try {
                if (endereco == null) {
                    enderecoDAO.salvar(atual);
                } else {
                    enderecoDAO.atualizar(atual);
                }
                carregarEnderecos();
                JOptionPane.showMessageDialog(dialog, "Endereço salvo com sucesso!");
                dialog.dispose();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(dialog, "Erro ao salvar endereço: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });

        JButton btnCancelar = new RoundedButton("CANCELAR", 24);
        styleActionButton(btnCancelar, new Color(220, 53, 69));
        btnCancelar.addActionListener(e -> dialog.dispose());

        buttonPanel.add(btnSalvar);
        buttonPanel.add(btnCancelar);

        JPanel topPanel = createDialogTopPanel(logoLabel, dialog);
        dialog.add(topPanel, BorderLayout.NORTH);
        dialog.add(formPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private void showAdicionarContactoModal(Contacto contacto) {
        JDialog dialog = createModalDialog(contacto == null ? "Adicionar Contacto" : "Editar Contacto");
        JLabel logoLabel = new JLabel();
        ImageIcon verificarLogo = loadIcon("src/view/img/verificar.png", 80, 80);
        if (verificarLogo != null) {
            logoLabel.setIcon(verificarLogo);
        } else {
            logoLabel.setText(contacto == null ? "ADICIONAR" : "EDITAR");
            logoLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
            logoLabel.setForeground(new Color(30, 40, 55));
        }

        JTextField txtTelefone1 = new JTextField(contacto != null ? contacto.getTelefone1() : "");
        JTextField txtTelefone2 = new JTextField(contacto != null ? contacto.getTelefone2() : "");

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        formPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 0, 8, 0);
        gbc.weightx = 1.0;

        gbc.gridy = 0;
        formPanel.add(createLabeledFieldPanel("Telefone 1", "src/view/icon/phone.png", txtTelefone1, 300, 50), gbc);
        gbc.gridy = 1;
        formPanel.add(createLabeledFieldPanel("Telefone 2", "src/view/icon/phone.png", txtTelefone2, 300, 50), gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.setBorder(new EmptyBorder(30, 20, 20, 20));

        JButton btnSalvar = new RoundedButton(contacto == null ? "SALVAR" : "SALVAR ALTERAÇÃO", 24);
        styleActionButton(btnSalvar, new Color(34, 197, 94));
        btnSalvar.addActionListener(e -> {
            String telefone1 = getFieldValue(txtTelefone1, "Telefone 1");
            String telefone2 = getFieldValue(txtTelefone2, "Telefone 2");
            if (telefone1.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Preencha o telefone principal.", "Atenção", JOptionPane.WARNING_MESSAGE);
                return;
            }
            Contacto atual = contacto != null ? contacto : new Contacto();
            atual.setTelefone1(telefone1);
            atual.setTelefone2(telefone2);
            try {
                if (contacto == null) {
                    contactoDAO.salvar(atual);
                } else {
                    contactoDAO.atualizar(atual);
                }
                carregarContactos();
                JOptionPane.showMessageDialog(dialog, "Contacto salvo com sucesso!");
                dialog.dispose();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(dialog, "Erro ao salvar contacto: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });

        JButton btnCancelar = new RoundedButton("CANCELAR", 24);
        styleActionButton(btnCancelar, new Color(220, 53, 69));
        btnCancelar.addActionListener(e -> dialog.dispose());

        buttonPanel.add(btnSalvar);
        buttonPanel.add(btnCancelar);

        JPanel topPanel = createDialogTopPanel(logoLabel, dialog);
        dialog.add(topPanel, BorderLayout.NORTH);
        dialog.add(formPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private void showAdicionarFuncaoModal(Funcao funcao) {
        JDialog dialog = createModalDialog(funcao == null ? "Adicionar Função" : "Editar Função");
        JLabel logoLabel = new JLabel();
        ImageIcon verificarLogo = loadIcon("src/view/img/verificar.png", 80, 80);
        if (verificarLogo != null) {
            logoLabel.setIcon(verificarLogo);
        } else {
            logoLabel.setText(funcao == null ? "ADICIONAR" : "EDITAR");
            logoLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
            logoLabel.setForeground(new Color(30, 40, 55));
        }

        JTextField txtFuncao = new JTextField(funcao != null ? funcao.getFuncao() : "");
        JTextField txtDescricao = new JTextField(funcao != null ? funcao.getDescricao() : "");
        ((AbstractDocument) txtFuncao.getDocument()).setDocumentFilter(new LetterOnlyFilter());

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        formPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 0, 8, 0);
        gbc.weightx = 1.0;

        gbc.gridy = 0;
        formPanel.add(createLabeledFieldPanel("Função", "src/view/icon/funcao.png", txtFuncao, 300, 50), gbc);
        gbc.gridy = 1;
        formPanel.add(createLabeledFieldPanel("Descrição", "src/view/icon/descricao.png", txtDescricao, 300, 50), gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.setBorder(new EmptyBorder(30, 20, 20, 20));

        JButton btnSalvar = new RoundedButton(funcao == null ? "SALVAR" : "SALVAR ALTERAÇÃO", 24);
        styleActionButton(btnSalvar, new Color(34, 197, 94));
        btnSalvar.addActionListener(e -> {
            String funcaoNome = getFieldValue(txtFuncao, "Função");
            String descricao = getFieldValue(txtDescricao, "Descrição");
            if (funcaoNome.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Preencha o nome da função.", "Atenção", JOptionPane.WARNING_MESSAGE);
                return;
            }
            Funcao atual = funcao != null ? funcao : new Funcao();
            atual.setFuncao(funcaoNome);
            atual.setDescricao(descricao);
            try {
                if (funcao == null) {
                    funcaoDAO.salvar(atual);
                } else {
                    funcaoDAO.atualizar(atual);
                }
                carregarFuncoes();
                JOptionPane.showMessageDialog(dialog, "Função salva com sucesso!");
                dialog.dispose();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(dialog, "Erro ao salvar função: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });

        JButton btnCancelar = new RoundedButton("CANCELAR", 24);
        styleActionButton(btnCancelar, new Color(220, 53, 69));
        btnCancelar.addActionListener(e -> dialog.dispose());

        buttonPanel.add(btnSalvar);
        buttonPanel.add(btnCancelar);

        JPanel topPanel = createDialogTopPanel(logoLabel, dialog);
        dialog.add(topPanel, BorderLayout.NORTH);
        dialog.add(formPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private void deleteEnderecoRow(int row) {
        if (row < 0 || enderecosTableModel == null) {
            return;
        }
        int resposta = JOptionPane.showConfirmDialog(this, "Deseja realmente deletar este endereço?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (resposta != JOptionPane.YES_OPTION) {
            return;
        }
        int id = Integer.parseInt(enderecosTableModel.getValueAt(row, 0).toString());
        try {
            enderecoDAO.deletar(id);
            enderecosTableModel.removeRow(row);
            JOptionPane.showMessageDialog(this, "Endereço deletado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao deletar endereço: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void viewEnderecoRow(int row) {
        if (row < 0 || enderecosTableModel == null) {
            return;
        }
        String municipio = enderecosTableModel.getValueAt(row, 1).toString();
        String bairro = enderecosTableModel.getValueAt(row, 2).toString();
        JOptionPane.showMessageDialog(this,
                "Município: " + municipio + "\nBairro: " + bairro,
                "Detalhes do Endereço", JOptionPane.INFORMATION_MESSAGE);
    }

    private void editEnderecoRow(int row) {
        if (row < 0 || enderecosTableModel == null) {
            return;
        }
        int id = Integer.parseInt(enderecosTableModel.getValueAt(row, 0).toString());
        try {
            Endereco endereco = enderecoDAO.buscarPorId(id);
            if (endereco == null) {
                JOptionPane.showMessageDialog(this, "Endereço não encontrado para edição.", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }
            showAdicionarEnderecoModal(endereco);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar endereço: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteContactoRow(int row) {
        if (row < 0 || contactosTableModel == null) {
            return;
        }
        int resposta = JOptionPane.showConfirmDialog(this, "Deseja realmente deletar este contacto?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (resposta != JOptionPane.YES_OPTION) {
            return;
        }
        int id = Integer.parseInt(contactosTableModel.getValueAt(row, 0).toString());
        try {
            contactoDAO.deletar(id);
            contactosTableModel.removeRow(row);
            JOptionPane.showMessageDialog(this, "Contacto deletado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao deletar contacto: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void viewContactoRow(int row) {
        if (row < 0 || contactosTableModel == null) {
            return;
        }
        String telefone1 = contactosTableModel.getValueAt(row, 1).toString();
        String telefone2 = contactosTableModel.getValueAt(row, 2).toString();
        JOptionPane.showMessageDialog(this,
                "Telefone 1: " + telefone1 + "\nTelefone 2: " + telefone2,
                "Detalhes do Contacto", JOptionPane.INFORMATION_MESSAGE);
    }

    private void editContactoRow(int row) {
        if (row < 0 || contactosTableModel == null) {
            return;
        }
        int id = Integer.parseInt(contactosTableModel.getValueAt(row, 0).toString());
        try {
            Contacto contacto = contactoDAO.buscarPorId(id);
            if (contacto == null) {
                JOptionPane.showMessageDialog(this, "Contacto não encontrado para edição.", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }
            showAdicionarContactoModal(contacto);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar contacto: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteFuncaoRow(int row) {
        if (row < 0 || funcoesTableModel == null) {
            return;
        }
        int resposta = JOptionPane.showConfirmDialog(this, "Deseja realmente deletar esta função?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (resposta != JOptionPane.YES_OPTION) {
            return;
        }
        int id = Integer.parseInt(funcoesTableModel.getValueAt(row, 0).toString());
        try {
            funcaoDAO.deletar(id);
            funcoesTableModel.removeRow(row);
            JOptionPane.showMessageDialog(this, "Função deletada com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao deletar função: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void viewFuncaoRow(int row) {
        if (row < 0 || funcoesTableModel == null) {
            return;
        }
        String nome = funcoesTableModel.getValueAt(row, 1).toString();
        String descricao = funcoesTableModel.getValueAt(row, 2).toString();
        JOptionPane.showMessageDialog(this,
                "Função: " + nome + "\nDescrição: " + descricao,
                "Detalhes da Função", JOptionPane.INFORMATION_MESSAGE);
    }

    private void editFuncaoRow(int row) {
        if (row < 0 || funcoesTableModel == null) {
            return;
        }
        int id = Integer.parseInt(funcoesTableModel.getValueAt(row, 0).toString());
        try {
            Funcao funcao = funcaoDAO.buscarPorId(id);
            if (funcao == null) {
                JOptionPane.showMessageDialog(this, "Função não encontrada para edição.", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }
            showAdicionarFuncaoModal(funcao);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar função: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private JPanel createGerenciarEmprestimosPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 248, 252));

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);

        JLabel title = new JLabel("Gerenciar Empréstimos");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(new Color(30, 40, 55));
        title.setBorder(new EmptyBorder(20, 20, 10, 20));
        topPanel.add(title, BorderLayout.WEST);

        JButton btnNovo = createPrimaryButton("Adicionar Empréstimo");
        btnNovo.addActionListener(e -> showAdicionarEmprestimoModal(null));
        topPanel.add(btnNovo, BorderLayout.EAST);

        panel.add(topPanel, BorderLayout.NORTH);

        emprestimosTableModel = new DefaultTableModel(new Object[]{"ID", "Estudante", "Livro", "Empréstimo", "Entrega", "Status", "Ações"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 6;
            }
        };

        emprestimosTable = new JTable(emprestimosTableModel);
        emprestimosTable.setRowHeight(40);
        emprestimosTable.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        emprestimosTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        emprestimosTable.getTableHeader().setBackground(new Color(240, 245, 250));
        emprestimosTable.getTableHeader().setForeground(new Color(30, 40, 55));
        emprestimosTable.setSelectionBackground(new Color(220, 235, 255));
        emprestimosTable.setGridColor(new Color(200, 210, 220));
        emprestimosTable.getColumnModel().getColumn(6).setCellRenderer(new ButtonRenderer());
        emprestimosTable.getColumnModel().getColumn(6).setCellEditor(new ButtonEditor(new JCheckBox(), emprestimosTable, this::deleteEmprestimoRow, this::viewEmprestimoRow, this::editEmprestimoRow));

        JScrollPane scrollPane = new JScrollPane(emprestimosTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 210, 220), 1));
        panel.add(scrollPane, BorderLayout.CENTER);

        carregarEmprestimos();
        return panel;
    }

    private void carregarEmprestimos() {
        if (emprestimosTableModel == null) {
            return;
        }

        emprestimosTableModel.setRowCount(0);
        List<Emprestimo> emprestimos = emprestimoDAO.listarTodos();
        for (Emprestimo emprestimo : emprestimos) {
            String estudanteNome = "N/A";
            String livroTitulo = "N/A";
            if (emprestimo.getIdEstudante() > 0) {
                try {
                    Estudante estudante = new EstudanteDAO().buscarPorId(emprestimo.getIdEstudante());
                    if (estudante != null) {
                        estudanteNome = estudante.getNome() + " (" + estudante.getNumeroEstudante() + ")";
                    }
                } catch (SQLException ex) {
                    estudanteNome = "Erro ao carregar estudante";
                }
            }
            if (emprestimo.getIdLivro() > 0) {
                try {
                    Livro livro = livroDAO.buscarPorId(emprestimo.getIdLivro());
                    if (livro != null) {
                        livroTitulo = livro.getTitulo();
                    }
                } catch (SQLException ex) {
                    livroTitulo = "Erro ao carregar livro";
                }
            }
            String dataEntrega = emprestimo.getDataEntrega() != null ? emprestimo.getDataEntrega().toString() + " " + (emprestimo.getHoraDeEntrega() != null ? emprestimo.getHoraDeEntrega().toString() : "") : "";
            String dataEmprestimo = emprestimo.getDataDeEmprestimo() != null ? emprestimo.getDataDeEmprestimo().toString() : "";
            emprestimosTableModel.addRow(new Object[]{
                emprestimo.getIdEmprestimo(),
                estudanteNome,
                livroTitulo,
                dataEmprestimo,
                dataEntrega,
                emprestimo.getAcao(),
                "Ações"
            });
        }
    }

    private void showAdicionarEmprestimoModal(Emprestimo emprestimo) {
        JDialog dialog = createModalDialog(emprestimo == null ? "Adicionar Empréstimo" : "Editar Empréstimo");
        JLabel logoLabel = new JLabel();
        ImageIcon verificarLogo = loadIcon("src/view/img/verificar.png", 80, 80);
        if (verificarLogo != null) {
            logoLabel.setIcon(verificarLogo);
        } else {
            logoLabel.setText(emprestimo == null ? "ADICIONAR" : "EDITAR");
            logoLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
            logoLabel.setForeground(new Color(30, 40, 55));
        }

        JComboBox<Estudante> comboEstudante = new JComboBox<>();
        comboEstudante.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof Estudante) {
                    Estudante estudante = (Estudante) value;
                    String nome = estudante.getNome() != null ? estudante.getNome() : "Nenhum estudante";
                    String numero = estudante.getNumeroEstudante() != null ? estudante.getNumeroEstudante() : "";
                    setText(nome + (numero.isEmpty() ? "" : " (" + numero + ")"));
                }
                return this;
            }
        });

        JComboBox<Livro> comboLivro = new JComboBox<>();
        comboLivro.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof Livro) {
                    Livro livro = (Livro) value;
                    setText(livro.getTitulo() != null ? livro.getTitulo() : "Nenhum livro");
                }
                return this;
            }
        });

        try {
            List<Estudante> estudantes = new EstudanteDAO().listarTodos();
            if (estudantes.isEmpty()) {
                Estudante vazio = new Estudante();
                vazio.setNome("Nenhum estudante cadastrado");
                comboEstudante.addItem(vazio);
                comboEstudante.setEnabled(false);
            } else {
                for (Estudante estudante : estudantes) {
                    comboEstudante.addItem(estudante);
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(dialog, "Erro ao carregar estudantes: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }

        try {
            List<Livro> livros = livroDAO.listarTodos();
            if (livros.isEmpty()) {
                Livro vazio = new Livro();
                vazio.setTitulo("Nenhum livro cadastrado");
                comboLivro.addItem(vazio);
                comboLivro.setEnabled(false);
            } else {
                for (Livro livro : livros) {
                    comboLivro.addItem(livro);
                }
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(dialog, "Erro ao carregar livros: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }

        JTextField txtValor = new JTextField(emprestimo != null ? String.valueOf(emprestimo.getValor()) : "");
        JComboBox<String> cbAcao = new JComboBox<>(new String[]{"Nao", "Devolvido"});
        JTextField txtDataEntrega = new JTextField(emprestimo != null && emprestimo.getDataEntrega() != null ? emprestimo.getDataEntrega().toString() : "");
        JTextField txtHoraEntrega = new JTextField(emprestimo != null && emprestimo.getHoraDeEntrega() != null ? emprestimo.getHoraDeEntrega().toString() : "");

        if (emprestimo != null && emprestimo.getAcao() != null) {
            cbAcao.setSelectedItem(emprestimo.getAcao());
        }

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        formPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 0, 8, 0);
        gbc.weightx = 1.0;

        gbc.gridy = 0;
        formPanel.add(createLabeledComboPanel("Estudante", "src/view/icon/user.png", comboEstudante, 300, 50), gbc);
        gbc.gridy = 1;
        formPanel.add(createLabeledComboPanel("Livro", "src/view/icon/livro.png", comboLivro, 300, 50), gbc);
        gbc.gridy = 2;
        formPanel.add(createLabeledFieldPanel("Valor", "src/view/icon/valor.png", txtValor, 300, 50), gbc);
        gbc.gridy = 3;
        formPanel.add(createLabeledComboPanel("Status", "src/view/icon/status.png", cbAcao, 300, 50), gbc);
        gbc.gridy = 4;
        formPanel.add(createLabeledFieldPanel("Data de Entrega", "src/view/icon/calendario.png", txtDataEntrega, 300, 50), gbc);
        gbc.gridy = 5;
        formPanel.add(createLabeledFieldPanel("Hora de Entrega", "src/view/icon/relogio.png", txtHoraEntrega, 300, 50), gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.setBorder(new EmptyBorder(30, 20, 20, 20));

        JButton btnSalvar = new RoundedButton(emprestimo == null ? "SALVAR" : "SALVAR ALTERAÇÃO", 24);
        styleActionButton(btnSalvar, new Color(34, 197, 94));
        btnSalvar.addActionListener(e -> {
            Estudante selecionado = (Estudante) comboEstudante.getSelectedItem();
            Livro livroSelecionado = (Livro) comboLivro.getSelectedItem();
            String valorText = getFieldValue(txtValor, "Valor");
            String status = (String) cbAcao.getSelectedItem();
            String dataEntregaText = getFieldValue(txtDataEntrega, "Data de Entrega");
            String horaEntregaText = getFieldValue(txtHoraEntrega, "Hora de Entrega");

            if (selecionado == null || selecionado.getIdEstudante() == 0) {
                JOptionPane.showMessageDialog(dialog, "Selecione um estudante válido.", "Atenção", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (livroSelecionado == null || livroSelecionado.getIdLivro() == 0) {
                JOptionPane.showMessageDialog(dialog, "Selecione um livro válido.", "Atenção", JOptionPane.WARNING_MESSAGE);
                return;
            }
            double valor = 0;
            if (!valorText.isEmpty()) {
                try {
                    valor = Double.parseDouble(valorText.replace(',', '.'));
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(dialog, "Valor inválido.", "Atenção", JOptionPane.WARNING_MESSAGE);
                    return;
                }
            }

            Emprestimo atual = emprestimo != null ? emprestimo : new Emprestimo();
            atual.setIdEstudante(selecionado.getIdEstudante());
            atual.setIdLivro(livroSelecionado.getIdLivro());
            if (emprestimo == null) {
                atual.setDataDeEmprestimo(new java.sql.Date(System.currentTimeMillis()));
                atual.setHoraDeEmprestimo(new java.sql.Time(System.currentTimeMillis()));
            }

            java.sql.Date dataEntrega = null;
            if (!dataEntregaText.isEmpty()) {
                try {
                    dataEntrega = java.sql.Date.valueOf(dataEntregaText);
                } catch (IllegalArgumentException ex) {
                    JOptionPane.showMessageDialog(dialog, "Formato de data de entrega inválido. Use YYYY-MM-DD.", "Atenção", JOptionPane.WARNING_MESSAGE);
                    return;
                }
            } else {
                dataEntrega = new java.sql.Date(System.currentTimeMillis() + 7L * 24 * 60 * 60 * 1000);
            }
            atual.setDataEntrega(dataEntrega);

            java.sql.Time horaEntrega;
            if (!horaEntregaText.isEmpty()) {
                try {
                    horaEntrega = java.sql.Time.valueOf(horaEntregaText);
                } catch (IllegalArgumentException ex) {
                    JOptionPane.showMessageDialog(dialog, "Formato de hora de entrega inválido. Use HH:MM:SS.", "Atenção", JOptionPane.WARNING_MESSAGE);
                    return;
                }
            } else {
                horaEntrega = new java.sql.Time(System.currentTimeMillis());
            }
            atual.setHoraDeEntrega(horaEntrega);

            atual.setValor(valor);
            atual.setAcao(status);
            if ("Devolvido".equalsIgnoreCase(status)) {
                atual.setDataEHoraDaEntrega(new java.util.Date());
            } else {
                atual.setDataEHoraDaEntrega(null);
            }
            if (funcionarioAutenticado != null) {
                atual.setIdFuncionario(funcionarioAutenticado.getIdFuncionario());
            }

            try {
                if (emprestimo == null) {
                    emprestimoDAO.salvar(atual);
                } else {
                    emprestimoDAO.atualizar(atual);
                }
                carregarEmprestimos();
                JOptionPane.showMessageDialog(dialog, "Empréstimo salvo com sucesso!");
                dialog.dispose();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Erro ao salvar empréstimo: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });

        JButton btnCancelar = new RoundedButton("CANCELAR", 24);
        styleActionButton(btnCancelar, new Color(220, 53, 69));
        btnCancelar.addActionListener(e -> dialog.dispose());

        buttonPanel.add(btnSalvar);
        buttonPanel.add(btnCancelar);

        JPanel topPanelDialog = createDialogTopPanel(logoLabel, dialog);
        dialog.add(topPanelDialog, BorderLayout.NORTH);
        dialog.add(formPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private void deleteEmprestimoRow(int row) {
        if (row < 0 || emprestimosTableModel == null) {
            return;
        }

        int resposta = JOptionPane.showConfirmDialog(this, "Deseja realmente deletar este empréstimo?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (resposta != JOptionPane.YES_OPTION) {
            return;
        }

        int id = Integer.parseInt(emprestimosTableModel.getValueAt(row, 0).toString());
        try {
            emprestimoDAO.deletar(id);
            emprestimosTableModel.removeRow(row);
            JOptionPane.showMessageDialog(this, "Empréstimo deletado com sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao deletar empréstimo: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void viewEmprestimoRow(int row) {
        if (row < 0 || emprestimosTableModel == null) {
            return;
        }

        String estudante = emprestimosTableModel.getValueAt(row, 1).toString();
        String livro = emprestimosTableModel.getValueAt(row, 2).toString();
        String dataEmprestimo = emprestimosTableModel.getValueAt(row, 3).toString();
        String dataEntrega = emprestimosTableModel.getValueAt(row, 4).toString();
        String status = emprestimosTableModel.getValueAt(row, 5).toString();

        JOptionPane.showMessageDialog(this,
                "Estudante: " + estudante + "\nLivro: " + livro + "\nEmpréstimo: " + dataEmprestimo + "\nEntrega: " + dataEntrega + "\nStatus: " + status,
                "Detalhes do Empréstimo", JOptionPane.INFORMATION_MESSAGE);
    }

    private void editEmprestimoRow(int row) {
        if (row < 0 || emprestimosTableModel == null) {
            return;
        }

        int id = Integer.parseInt(emprestimosTableModel.getValueAt(row, 0).toString());
        try {
            Emprestimo emprestimo = emprestimoDAO.buscarPorId(id);
            if (emprestimo == null) {
                JOptionPane.showMessageDialog(this, "Empréstimo não encontrado para edição.", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }
            showAdicionarEmprestimoModal(emprestimo);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar empréstimo: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private JPanel createGerenciarRelatoriosPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(245, 248, 252));
        JLabel title = new JLabel("Relatórios");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(new Color(30, 40, 55));
        title.setBorder(new EmptyBorder(20, 20, 10, 20));

        JTextArea reportArea = new JTextArea("Relatórios gerais do sistema aparecerão aqui.\n\n- Total de estudantes\n- Total de livros\n- Total de computadores\n- Ocupação de armários\n- Cursos cadastrados\n- Departamentos cadastrados");
        reportArea.setEditable(false);
        reportArea.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        reportArea.setBackground(new Color(245, 248, 252));
        reportArea.setBorder(new EmptyBorder(20, 20, 20, 20));

        panel.add(title, new GridBagConstraints());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1;
        gbc.weighty = 1;
        gbc.insets = new Insets(10, 20, 20, 20);
        panel.add(new JScrollPane(reportArea), gbc);

        return panel;
    }

    private JButton createPrimaryButton(String text) {
        JButton button = new RoundedButton(text, 20);
        button.setPreferredSize(new Dimension(140, 36));
        button.setBackground(new Color(34, 197, 94));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.BOLD, 13));
        button.setBorder(new LineBorder(new Color(34, 197, 94), 2, true));
        return button;
    }

    private void carregarFuncionarios() {
        funcionariosTableModel.setRowCount(0);
        try {
            List<Funcionario> funcionarios = funcionarioDAO.listarTodos();
            for (Funcionario funcionario : funcionarios) {
                funcionariosTableModel.addRow(new Object[]{
                    funcionario.getIdFuncionario(),
                    funcionario.getNome(),
                    funcionario.getFuncao(),
                    funcionario.getContacto(),
                    "Ações"
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar funcionários: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarLivros() {
        livrosTableModel.setRowCount(0);
        List<Livro> livros = livroDAO.listarTodos();
        for (Livro livro : livros) {
            livrosTableModel.addRow(new Object[]{
                livro.getIdLivro(),
                livro.getTitulo(),
                livro.getCodigo(),
                livro.getArmarioNome(),
                livro.isDisponivel() ? "Disponível" : "Indisponível",
                "Ações"
            });
        }
    }

    private void carregarComputadores() {
        computadoresTableModel.setRowCount(0);
        try {
            List<Computador> computadores = computadorDAO.listarTodos();
            for (Computador computador : computadores) {
                computadoresTableModel.addRow(new Object[]{
                    computador.getIdComputador(),
                    computador.getMarca(),
                    computador.getModelo(),
                    computador.isEmUso() ? "Em uso" : "Disponível",
                    "Ações"
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar computadores: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarArmarios() {
        armariosTableModel.setRowCount(0);
        try {
            List<Armario> armarios = armarioDAO.listarTodos();
            for (Armario armario : armarios) {
                armariosTableModel.addRow(new Object[]{
                    armario.getIdArmario(),
                    armario.getArmario(),
                    "Ações"
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar armários: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarCursosTabela() {
        cursosTableModel.setRowCount(0);
        try {
            List<Curso> cursos = cursoDAO.listarTodos();
            for (Curso curso : cursos) {
                cursosTableModel.addRow(new Object[]{
                    curso.getIdCurso(),
                    curso.getCurso(),
                    curso.getDepartamento(),
                    "Ações"
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar cursos: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarDepartamentos() {
        departamentosTableModel.setRowCount(0);
        try {
            List<Departamento> departamentos = departamentoDAO.listarTodos();
            for (Departamento departamento : departamentos) {
                departamentosTableModel.addRow(new Object[]{
                    departamento.getIdDepartamento(),
                    departamento.getDepartamento(),
                    "Ações"
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar departamentos: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private List<Curso> carregarCursoItems() {
        try {
            return cursoDAO.listarTodos();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar cursos: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            return new java.util.ArrayList<>();
        }
    }

    private void deleteFuncionarioRow(int row) {
        if (row < 0 || funcionariosTableModel == null) {
            return;
        }
        int resposta = JOptionPane.showConfirmDialog(this, "Deseja realmente deletar este funcionário?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (resposta != JOptionPane.YES_OPTION) {
            return;
        }
        int id = Integer.parseInt(funcionariosTableModel.getValueAt(row, 0).toString());
        try {
            funcionarioDAO.deletar(id);
            funcionariosTableModel.removeRow(row);
            JOptionPane.showMessageDialog(this, "Funcionário deletado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao deletar funcionário: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteLivroRow(int row) {
        if (row < 0 || livrosTableModel == null) {
            return;
        }
        int resposta = JOptionPane.showConfirmDialog(this, "Deseja realmente deletar este livro?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (resposta != JOptionPane.YES_OPTION) {
            return;
        }
        int id = Integer.parseInt(livrosTableModel.getValueAt(row, 0).toString());
        livroDAO.deletar(id);
        livrosTableModel.removeRow(row);
        JOptionPane.showMessageDialog(this, "Livro deletado com sucesso!");
    }

    private void deleteComputadorRow(int row) {
        if (row < 0 || computadoresTableModel == null) {
            return;
        }
        int resposta = JOptionPane.showConfirmDialog(this, "Deseja realmente deletar este computador?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (resposta != JOptionPane.YES_OPTION) {
            return;
        }
        int id = Integer.parseInt(computadoresTableModel.getValueAt(row, 0).toString());
        try {
            computadorDAO.deletar(id);
            computadoresTableModel.removeRow(row);
            JOptionPane.showMessageDialog(this, "Computador deletado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao deletar computador: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteArmarioRow(int row) {
        if (row < 0 || armariosTableModel == null) {
            return;
        }
        int resposta = JOptionPane.showConfirmDialog(this, "Deseja realmente deletar este armário?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (resposta != JOptionPane.YES_OPTION) {
            return;
        }
        int id = Integer.parseInt(armariosTableModel.getValueAt(row, 0).toString());
        try {
            armarioDAO.deletar(id);
            armariosTableModel.removeRow(row);
            JOptionPane.showMessageDialog(this, "Armário deletado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao deletar armário: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteCursoRow(int row) {
        if (row < 0 || cursosTableModel == null) {
            return;
        }
        int resposta = JOptionPane.showConfirmDialog(this, "Deseja realmente deletar este curso?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (resposta != JOptionPane.YES_OPTION) {
            return;
        }
        int id = Integer.parseInt(cursosTableModel.getValueAt(row, 0).toString());
        try {
            cursoDAO.deletar(id);
            cursosTableModel.removeRow(row);
            JOptionPane.showMessageDialog(this, "Curso deletado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao deletar curso: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteDepartamentoRow(int row) {
        if (row < 0 || departamentosTableModel == null) {
            return;
        }
        int resposta = JOptionPane.showConfirmDialog(this, "Deseja realmente deletar este departamento?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (resposta != JOptionPane.YES_OPTION) {
            return;
        }
        int id = Integer.parseInt(departamentosTableModel.getValueAt(row, 0).toString());
        try {
            departamentoDAO.deletar(id);
            departamentosTableModel.removeRow(row);
            JOptionPane.showMessageDialog(this, "Departamento deletado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao deletar departamento: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void viewFuncionarioRow(int row) {
        if (row < 0 || funcionariosTableModel == null) {
            return;
        }
        String nome = funcionariosTableModel.getValueAt(row, 1).toString();
        String cargo = funcionariosTableModel.getValueAt(row, 2).toString();
        String contacto = funcionariosTableModel.getValueAt(row, 3).toString();
        JOptionPane.showMessageDialog(this,
                "Nome: " + nome + "\nCargo: " + cargo + "\nContacto: " + contacto,
                "Detalhes do Funcionário", JOptionPane.INFORMATION_MESSAGE);
    }

    private void editFuncionarioRow(int row) {
        if (row < 0 || funcionariosTableModel == null) {
            return;
        }
        int idFuncionario = Integer.parseInt(funcionariosTableModel.getValueAt(row, 0).toString());
        try {
            Funcionario funcionario = funcionarioController.buscarPorId(idFuncionario);
            if (funcionario == null) {
                JOptionPane.showMessageDialog(this, "Funcionário não encontrado para edição.", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }
            showAdicionarFuncionarioModal(funcionario);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar funcionário: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void viewLivroRow(int row) {
        if (row < 0 || livrosTableModel == null) {
            return;
        }
        String titulo = livrosTableModel.getValueAt(row, 1).toString();
        String codigo = livrosTableModel.getValueAt(row, 3).toString();
        String armario = livrosTableModel.getValueAt(row, 4).toString();
        String status = livrosTableModel.getValueAt(row, 5).toString();
        JOptionPane.showMessageDialog(this,
                "Título: " + titulo + "\nCódigo: " + codigo + "\nArmário: " + armario + "\nStatus: " + status,
                "Detalhes do Livro", JOptionPane.INFORMATION_MESSAGE);
    }

    private void editLivroRow(int row) {
        if (row < 0 || livrosTableModel == null) {
            return;
        }
        int idLivro = Integer.parseInt(livrosTableModel.getValueAt(row, 0).toString());
        try {
            Livro livro = livroDAO.buscarPorId(idLivro);
            if (livro == null) {
                JOptionPane.showMessageDialog(this, "Livro não encontrado para edição.", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }
            showAdicionarLivroModal(livro);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar livro: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void viewComputadorRow(int row) {
        if (row < 0 || computadoresTableModel == null) {
            return;
        }
        String marca = computadoresTableModel.getValueAt(row, 1).toString();
        String modelo = computadoresTableModel.getValueAt(row, 2).toString();
        String status = computadoresTableModel.getValueAt(row, 3).toString();
        JOptionPane.showMessageDialog(this,
                "Marca: " + marca + "\nModelo: " + modelo + "\nStatus: " + status,
                "Detalhes do Computador", JOptionPane.INFORMATION_MESSAGE);
    }

    private void editComputadorRow(int row) {
        if (row < 0 || computadoresTableModel == null) {
            return;
        }
        int idComputador = Integer.parseInt(computadoresTableModel.getValueAt(row, 0).toString());
        try {
            Computador computador = computadorDAO.buscarPorId(idComputador);
            if (computador == null) {
                JOptionPane.showMessageDialog(this, "Computador não encontrado para edição.", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }
            showAdicionarComputadorModal(computador);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar computador: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void viewArmarioRow(int row) {
        if (row < 0 || armariosTableModel == null) {
            return;
        }
        String armario = armariosTableModel.getValueAt(row, 1).toString();
        JOptionPane.showMessageDialog(this,
                "Armário: " + armario,
                "Detalhes do Armário", JOptionPane.INFORMATION_MESSAGE);
    }

    private void editArmarioRow(int row) {
        if (row < 0 || armariosTableModel == null) {
            return;
        }
        int idArmario = Integer.parseInt(armariosTableModel.getValueAt(row, 0).toString());
        try {
            Armario armario = armarioDAO.buscarPorId(idArmario);
            if (armario == null) {
                JOptionPane.showMessageDialog(this, "Armário não encontrado para edição.", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }
            showAdicionarArmarioModal(armario);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar armário: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void viewCursoRow(int row) {
        if (row < 0 || cursosTableModel == null) {
            return;
        }
        String curso = cursosTableModel.getValueAt(row, 1).toString();
        String departamento = cursosTableModel.getValueAt(row, 2).toString();
        JOptionPane.showMessageDialog(this,
                "Curso: " + curso + "\nDepartamento: " + departamento,
                "Detalhes do Curso", JOptionPane.INFORMATION_MESSAGE);
    }

    private void editCursoRow(int row) {
        if (row < 0 || cursosTableModel == null) {
            return;
        }
        int idCurso = Integer.parseInt(cursosTableModel.getValueAt(row, 0).toString());
        try {
            Curso curso = new Curso();
            curso.setIdCurso(idCurso);
            curso.setCurso(cursosTableModel.getValueAt(row, 1).toString());
            curso.setDepartamento(cursosTableModel.getValueAt(row, 2).toString());
            showAdicionarCursoModal(curso);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar curso para edição: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void viewDepartamentoRow(int row) {
        if (row < 0 || departamentosTableModel == null) {
            return;
        }
        String departamento = departamentosTableModel.getValueAt(row, 1).toString();
        JOptionPane.showMessageDialog(this,
                "Departamento: " + departamento,
                "Detalhes do Departamento", JOptionPane.INFORMATION_MESSAGE);
    }

    private void editDepartamentoRow(int row) {
        if (row < 0 || departamentosTableModel == null) {
            return;
        }
        int idDepartamento = Integer.parseInt(departamentosTableModel.getValueAt(row, 0).toString());
        try {
            Departamento departamento = new Departamento();
            departamento.setIdDepartamento(idDepartamento);
            departamento.setDepartamento(departamentosTableModel.getValueAt(row, 1).toString());
            showAdicionarDepartamentoModal(departamento);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar departamento para edição: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void showAdicionarFuncionarioModal(Funcionario funcionario) {
        JDialog dialog = createModalDialog("Adicionar Funcionário");
        JLabel logoLabel = new JLabel();
        ImageIcon verificarLogo = loadIcon("src/view/img/verificar.png", 80, 80);
        if (verificarLogo != null) {
            logoLabel.setIcon(verificarLogo);
        } else {
            logoLabel.setText("ADICIONAR");
            logoLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
            logoLabel.setForeground(new Color(30, 40, 55));
        }

        JTextField txtNome = new JTextField(funcionario != null ? funcionario.getNome() : "");
        JTextField txtCargo = new JTextField(funcionario != null ? funcionario.getFuncao() : "");
        JPasswordField txtSenha = new JPasswordField(funcionario != null ? funcionario.getSenha() : "");
        JTextField txtContacto = new JTextField(funcionario != null ? funcionario.getContacto() : "");

        ((AbstractDocument) txtNome.getDocument()).setDocumentFilter(new LetterOnlyFilter());
        ((AbstractDocument) txtCargo.getDocument()).setDocumentFilter(new LetterOnlyFilter());

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        formPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 0, 8, 0);
        gbc.weightx = 1.0;

        gbc.gridy = 0;
        formPanel.add(createLabeledFieldPanel("Nome", "src/view/icon/user.png", txtNome, 300, 50), gbc);
        gbc.gridy = 1;
        formPanel.add(createLabeledFieldPanel("Cargo", "src/view/icon/user.png", txtCargo, 300, 50), gbc);
        gbc.gridy = 2;
        formPanel.add(createLabeledFieldPanel("Senha", "src/view/icon/lock.png", txtSenha, 300, 50), gbc);

        gbc.gridy = 3;
        formPanel.add(createLabeledFieldPanel("Contacto", "src/view/icon/user.png", txtContacto, 300, 50), gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.setBorder(new EmptyBorder(30, 20, 20, 20));

        JButton btnSalvar = new RoundedButton("SALVAR", 24);
        styleActionButton(btnSalvar, new Color(34, 197, 94));
        btnSalvar.addActionListener(e -> {
            String nome = getFieldValue(txtNome, "Nome");
            String cargo = getFieldValue(txtCargo, "Cargo");
            String senha = new String(txtSenha.getPassword()).trim();
            String contacto = getFieldValue(txtContacto, "Contacto");
            if (nome.isEmpty() || cargo.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Preencha nome e cargo.", "Atenção", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (funcionario == null && senha.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Informe uma senha para o novo funcionário.", "Atenção", JOptionPane.WARNING_MESSAGE);
                return;
            }
            Funcionario novo = funcionario != null ? funcionario : new Funcionario();
            novo.setNome(nome);
            novo.setFuncao(cargo);
            if (!senha.isEmpty()) {
                novo.setSenha(senha);
            }
            if (funcionario != null && novo.getSenha() == null) {
                novo.setSenha(funcionario.getSenha());
            }
            novo.setContacto(contacto);
            try {
                if (funcionario == null) {
                    funcionarioDAO.salvar(novo);
                } else {
                    funcionarioDAO.atualizar(novo);
                }
                carregarFuncionarios();
                JOptionPane.showMessageDialog(dialog, "Funcionário salvo com sucesso!");
                dialog.dispose();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(dialog, "Erro ao salvar funcionário: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });

        JButton btnCancelar = new RoundedButton("CANCELAR", 24);
        styleActionButton(btnCancelar, new Color(220, 53, 69));
        btnCancelar.addActionListener(e -> dialog.dispose());

        buttonPanel.add(btnSalvar);
        buttonPanel.add(btnCancelar);

        JPanel topPanel = createDialogTopPanel(logoLabel, dialog);
        dialog.add(topPanel, BorderLayout.NORTH);
        dialog.add(formPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private void showAdicionarLivroModal(Livro livro) {
        JDialog dialog = createModalDialog("Adicionar Livro");
        JLabel logoLabel = new JLabel();
        ImageIcon verificarLogo = loadIcon("src/view/img/verificar.png", 80, 80);
        if (verificarLogo != null) {
            logoLabel.setIcon(verificarLogo);
        } else {
            logoLabel.setText("ADICIONAR");
            logoLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
            logoLabel.setForeground(new Color(30, 40, 55));
        }

        JTextField txtTitulo = new JTextField(livro != null ? livro.getTitulo() : "");
        JTextField txtCor = new JTextField(livro != null ? livro.getCor() : "");
        JTextField txtPagina = new JTextField(livro != null ? String.valueOf(livro.getPagina()) : "");
        JTextField txtCodigo = new JTextField(livro != null ? livro.getCodigo() : "");
        JCheckBox cbDisponivel = new JCheckBox("Disponível", livro != null && livro.isDisponivel());
        cbDisponivel.setOpaque(false);

        JComboBox<Armario> comboArmario = new JComboBox<>();
        comboArmario.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof Armario) {
                    Armario armario = (Armario) value;
                    setText(armario.getArmario() != null ? armario.getArmario() : "Nenhum armário");
                }
                return this;
            }
        });
        List<Armario> armarios = carregarArmariosParaCombo();
        if (armarios.isEmpty()) {
            comboArmario.addItem(new Armario());
            comboArmario.setEnabled(false);
        } else {
            for (Armario armario : armarios) {
                comboArmario.addItem(armario);
            }
        }
        if (livro != null && livro.getIdArmario() != 0) {
            for (int i = 0; i < comboArmario.getItemCount(); i++) {
                Armario armario = comboArmario.getItemAt(i);
                if (armario != null && armario.getIdArmario() == livro.getIdArmario()) {
                    comboArmario.setSelectedIndex(i);
                    break;
                }
            }
        }

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        formPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 0, 8, 0);
        gbc.weightx = 1.0;

        gbc.gridy = 0;
        formPanel.add(createLabeledFieldPanel("Título", "src/view/icon/livro.png", txtTitulo, 300, 50), gbc);
        gbc.gridy = 1;
        formPanel.add(createLabeledFieldPanel("Cor", "src/view/icon/livro.png", txtCor, 300, 50), gbc);
        gbc.gridy = 2;
        formPanel.add(createLabeledFieldPanel("Páginas", "src/view/icon/user.png", txtPagina, 300, 50), gbc);
        gbc.gridy = 3;
        formPanel.add(createLabeledFieldPanel("Código", "src/view/icon/user.png", txtCodigo, 300, 50), gbc);
        gbc.gridy = 4;
        formPanel.add(createLabeledComboPanel("Armário", "src/view/icon/armario.png", comboArmario, 300, 50), gbc);
        gbc.gridy = 5;
        JPanel disponivelPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        disponivelPanel.setOpaque(false);
        disponivelPanel.add(cbDisponivel);
        formPanel.add(createLabeledComponentPanel("Disponível", "src/view/icon/check.png", disponivelPanel), gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.setBorder(new EmptyBorder(30, 20, 20, 20));

        JButton btnSalvar = new RoundedButton("SALVAR", 24);
        styleActionButton(btnSalvar, new Color(34, 197, 94));
        btnSalvar.addActionListener(e -> {
            String titulo = getFieldValue(txtTitulo, "Título");
            String cor = getFieldValue(txtCor, "Cor");
            String paginaText = getFieldValue(txtPagina, "Páginas");
            String codigo = getFieldValue(txtCodigo, "Código");
            int paginas = paginaText.isEmpty() ? 0 : Integer.parseInt(paginaText);
            Armario armarioSelecionado = (Armario) comboArmario.getSelectedItem();
            if (titulo.isEmpty() || codigo.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Preencha título e código.", "Atenção", JOptionPane.WARNING_MESSAGE);
                return;
            }
            Livro novo = livro != null ? livro : new Livro();
            novo.setTitulo(titulo);
            novo.setCor(cor);
            novo.setPagina(paginas);
            novo.setCodigo(codigo);
            novo.setDisponivel(cbDisponivel.isSelected());
            if (armarioSelecionado != null && armarioSelecionado.getIdArmario() != 0) {
                novo.setIdArmario(armarioSelecionado.getIdArmario());
            }
            if (livro == null) {
                livroDAO.salvar(novo);
            } else {
                livroDAO.atualizar(novo);
            }
            carregarLivros();
            JOptionPane.showMessageDialog(dialog, "Livro salvo com sucesso!");
            dialog.dispose();
        });

        JButton btnCancelar = new RoundedButton("CANCELAR", 24);
        styleActionButton(btnCancelar, new Color(220, 53, 69));
        btnCancelar.addActionListener(e -> dialog.dispose());

        buttonPanel.add(btnSalvar);
        buttonPanel.add(btnCancelar);

        JPanel topPanel = createDialogTopPanel(logoLabel, dialog);
        dialog.add(topPanel, BorderLayout.NORTH);
        dialog.add(formPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private void showAdicionarComputadorModal(Computador computador) {
        JDialog dialog = createModalDialog("Adicionar Computador");
        JLabel logoLabel = new JLabel();
        ImageIcon verificarLogo = loadIcon("src/view/img/verificar.png", 80, 80);
        if (verificarLogo != null) {
            logoLabel.setIcon(verificarLogo);
        } else {
            logoLabel.setText("ADICIONAR");
            logoLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
            logoLabel.setForeground(new Color(30, 40, 55));
        }

        JTextField txtMarca = new JTextField(computador != null ? computador.getMarca() : "");
        JTextField txtModelo = new JTextField(computador != null ? computador.getModelo() : "");
        JTextField txtNumero = new JTextField(computador != null ? computador.getNumero() : "");
        JCheckBox cbEmUso = new JCheckBox("Em uso", computador != null && computador.isEmUso());
        cbEmUso.setOpaque(false);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        formPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 0, 8, 0);
        gbc.weightx = 1.0;

        gbc.gridy = 0;
        formPanel.add(createLabeledFieldPanel("Marca", "src/view/icon/computador.png", txtMarca, 300, 50), gbc);
        gbc.gridy = 1;
        formPanel.add(createLabeledFieldPanel("Modelo", "src/view/icon/computador.png", txtModelo, 300, 50), gbc);
        gbc.gridy = 2;
        formPanel.add(createLabeledFieldPanel("Número", "src/view/icon/user.png", txtNumero, 300, 50), gbc);
        gbc.gridy = 3;
        JPanel statusPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        statusPanel.setOpaque(false);
        statusPanel.add(cbEmUso);
        formPanel.add(createLabeledComponentPanel("Em uso", "src/view/icon/check.png", statusPanel), gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.setBorder(new EmptyBorder(30, 20, 20, 20));

        JButton btnSalvar = new RoundedButton("SALVAR", 24);
        styleActionButton(btnSalvar, new Color(34, 197, 94));
        btnSalvar.addActionListener(e -> {
            String marca = getFieldValue(txtMarca, "Marca");
            String modelo = getFieldValue(txtModelo, "Modelo");
            String numero = getFieldValue(txtNumero, "Número");
            if (marca.isEmpty() || modelo.isEmpty() || numero.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Preencha marca, modelo e número.", "Atenção", JOptionPane.WARNING_MESSAGE);
                return;
            }
            Computador novo = computador != null ? computador : new Computador();
            novo.setMarca(marca);
            novo.setModelo(modelo);
            novo.setNumero(numero);
            novo.setEmUso(cbEmUso.isSelected());
            try {
                if (computador == null) {
                    computadorDAO.salvar(novo);
                } else {
                    computadorDAO.atualizar(novo);
                }
                carregarComputadores();
                JOptionPane.showMessageDialog(dialog, "Computador salvo com sucesso!");
                dialog.dispose();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(dialog, "Erro ao salvar computador: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });

        JButton btnCancelar = new RoundedButton("CANCELAR", 24);
        styleActionButton(btnCancelar, new Color(220, 53, 69));
        btnCancelar.addActionListener(e -> dialog.dispose());

        buttonPanel.add(btnSalvar);
        buttonPanel.add(btnCancelar);

        JPanel topPanel = createDialogTopPanel(logoLabel, dialog);
        dialog.add(topPanel, BorderLayout.NORTH);
        dialog.add(formPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private void showAdicionarArmarioModal(Armario armario) {
        JDialog dialog = createModalDialog("Adicionar Armário");
        JLabel logoLabel = new JLabel();
        ImageIcon verificarLogo = loadIcon("src/view/img/verificar.png", 80, 80);
        if (verificarLogo != null) {
            logoLabel.setIcon(verificarLogo);
        } else {
            logoLabel.setText("ADICIONAR");
            logoLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
            logoLabel.setForeground(new Color(30, 40, 55));
        }

        JTextField txtArmario = new JTextField(armario != null ? armario.getArmario() : "");

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        formPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 0, 8, 0);
        gbc.weightx = 1.0;

        gbc.gridy = 0;
        formPanel.add(createLabeledFieldPanel("Armário", "src/view/icon/armario.png", txtArmario, 300, 50), gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.setBorder(new EmptyBorder(30, 20, 20, 20));

        JButton btnSalvar = new RoundedButton("SALVAR", 24);
        styleActionButton(btnSalvar, new Color(34, 197, 94));
        btnSalvar.addActionListener(e -> {
            String armarioNome = getFieldValue(txtArmario, "Armário");
            if (armarioNome.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Preencha o nome do armário.", "Atenção", JOptionPane.WARNING_MESSAGE);
                return;
            }
            Armario novo = armario != null ? armario : new Armario();
            novo.setArmario(armarioNome);
            try {
                if (armario == null) {
                    armarioDAO.salvar(novo);
                } else {
                    armarioDAO.atualizar(novo);
                }
                carregarArmarios();
                JOptionPane.showMessageDialog(dialog, "Armário salvo com sucesso!");
                dialog.dispose();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(dialog, "Erro ao salvar armário: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });

        JButton btnCancelar = new RoundedButton("CANCELAR", 24);
        styleActionButton(btnCancelar, new Color(220, 53, 69));
        btnCancelar.addActionListener(e -> dialog.dispose());

        buttonPanel.add(btnSalvar);
        buttonPanel.add(btnCancelar);

        JPanel topPanel = createDialogTopPanel(logoLabel, dialog);
        dialog.add(topPanel, BorderLayout.NORTH);
        dialog.add(formPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private void showAdicionarCursoModal(Curso curso) {
        JDialog dialog = createModalDialog("Adicionar Curso");
        JLabel logoLabel = new JLabel();
        ImageIcon verificarLogo = loadIcon("src/view/img/verificar.png", 80, 80);
        if (verificarLogo != null) {
            logoLabel.setIcon(verificarLogo);
        } else {
            logoLabel.setText("ADICIONAR");
            logoLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
            logoLabel.setForeground(new Color(30, 40, 55));
        }

        JTextField txtCurso = new JTextField(curso != null ? curso.getCurso() : "");
        ((AbstractDocument) txtCurso.getDocument()).setDocumentFilter(new LetterOnlyFilter());

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        formPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 0, 8, 0);
        gbc.weightx = 1.0;

        gbc.gridy = 0;
        formPanel.add(createLabeledFieldPanel("Curso", "src/view/icon/curso.png", txtCurso, 300, 50), gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.setBorder(new EmptyBorder(30, 20, 20, 20));

        JButton btnSalvar = new RoundedButton("SALVAR", 24);
        styleActionButton(btnSalvar, new Color(34, 197, 94));
        btnSalvar.addActionListener(e -> {
            String nome = getFieldValue(txtCurso, "Curso");
            if (nome.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Preencha o nome do curso.", "Atenção", JOptionPane.WARNING_MESSAGE);
                return;
            }
            Curso novo = curso != null ? curso : new Curso();
            novo.setCurso(nome);
            try {
                if (curso == null) {
                    cursoDAO.salvar(novo);
                } else {
                    cursoDAO.atualizar(novo);
                }
                carregarCursosTabela();
                JOptionPane.showMessageDialog(dialog, "Curso salvo com sucesso!");
                dialog.dispose();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(dialog, "Erro ao salvar curso: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });

        JButton btnCancelar = new RoundedButton("CANCELAR", 24);
        styleActionButton(btnCancelar, new Color(220, 53, 69));
        btnCancelar.addActionListener(e -> dialog.dispose());

        buttonPanel.add(btnSalvar);
        buttonPanel.add(btnCancelar);

        JPanel topPanel = createDialogTopPanel(logoLabel, dialog);
        dialog.add(topPanel, BorderLayout.NORTH);
        dialog.add(formPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private void showAdicionarDepartamentoModal(Departamento departamento) {
        JDialog dialog = createModalDialog("Adicionar Departamento");
        JLabel logoLabel = new JLabel();
        ImageIcon verificarLogo = loadIcon("src/view/img/verificar.png", 80, 80);
        if (verificarLogo != null) {
            logoLabel.setIcon(verificarLogo);
        } else {
            logoLabel.setText("ADICIONAR");
            logoLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
            logoLabel.setForeground(new Color(30, 40, 55));
        }

        JTextField txtDepartamento = new JTextField(departamento != null ? departamento.getDepartamento() : "");
        ((AbstractDocument) txtDepartamento.getDocument()).setDocumentFilter(new LetterOnlyFilter());

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        formPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 0, 8, 0);
        gbc.weightx = 1.0;

        gbc.gridy = 0;
        formPanel.add(createLabeledFieldPanel("Departamento", "src/view/icon/departamento.png", txtDepartamento, 300, 50), gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.setBorder(new EmptyBorder(30, 20, 20, 20));

        JButton btnSalvar = new RoundedButton("SALVAR", 24);
        styleActionButton(btnSalvar, new Color(34, 197, 94));
        btnSalvar.addActionListener(e -> {
            String nome = getFieldValue(txtDepartamento, "Departamento");
            if (nome.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Preencha o nome do departamento.", "Atenção", JOptionPane.WARNING_MESSAGE);
                return;
            }
            Departamento novo = departamento != null ? departamento : new Departamento();
            novo.setDepartamento(nome);
            try {
                if (departamento == null) {
                    departamentoDAO.salvar(novo);
                } else {
                    departamentoDAO.atualizar(novo);
                }
                carregarDepartamentos();
                JOptionPane.showMessageDialog(dialog, "Departamento salvo com sucesso!");
                dialog.dispose();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(dialog, "Erro ao salvar departamento: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });

        JButton btnCancelar = new RoundedButton("CANCELAR", 24);
        styleActionButton(btnCancelar, new Color(220, 53, 69));
        btnCancelar.addActionListener(e -> dialog.dispose());

        buttonPanel.add(btnSalvar);
        buttonPanel.add(btnCancelar);

        JPanel topPanel = createDialogTopPanel(logoLabel, dialog);
        dialog.add(topPanel, BorderLayout.NORTH);
        dialog.add(formPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private JDialog createModalDialog(String title) {
        JDialog dialog = new JDialog(this, title, true);
        dialog.setSize(520, 540);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());
        dialog.setResizable(false);
        return dialog;
    }

    private JPanel createDialogTopPanel(JLabel logoLabel, JDialog dialog) {
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);
        topPanel.setBorder(new EmptyBorder(12, 12, 12, 12));
        topPanel.add(logoLabel, BorderLayout.WEST);
        return topPanel;
    }

    private List<Armario> carregarArmariosParaCombo() {
        try {
            return armarioDAO.listarTodos();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar armários: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            return new java.util.ArrayList<>();
        }
    }

    private void styleActionButton(JButton button, Color background) {
        button.setPreferredSize(new Dimension(140, 45));
        button.setMargin(new Insets(8, 16, 8, 16));
        button.setBackground(background);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBorder(new LineBorder(background, 2, true));
    }

    private JPanel createDashboardPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(240, 245, 250));
        JLabel title = new JLabel("Bem-vindo ao painel administrativo");
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(new Color(30, 40, 55));
        panel.add(title);
        return panel;
    }

    private JPanel createCardPanel(String titleText) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 248, 252));
        JLabel title = new JLabel(titleText);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(new Color(30, 40, 55));
        title.setBorder(new EmptyBorder(30, 30, 20, 30));
        panel.add(title, BorderLayout.NORTH);
        JLabel content = new JLabel("Conteúdo da tela " + titleText);
        content.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        content.setBorder(new EmptyBorder(10, 30, 10, 30));
        panel.add(content, BorderLayout.CENTER);
        return panel;
    }

    private ImageIcon loadIcon(String path, int width, int height) {
        try {
            BufferedImage image = ImageIO.read(new File(path));
            Image scaled = image.getScaledInstance(width, height, Image.SCALE_SMOOTH);
            return new ImageIcon(scaled);
        } catch (IOException e) {
            return null;
        }
    }

    private static class RoundedButton extends JButton {
        private final int radius;

        public RoundedButton(String text, int radius) {
            super(text);
            this.radius = radius;
            setOpaque(false);
            setContentAreaFilled(false);
            setFocusPainted(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            if (getModel().isPressed()) {
                g2.setColor(getBackground().darker());
            } else if (getModel().isRollover()) {
                g2.setColor(getBackground().brighter());
            } else {
                g2.setColor(getBackground());
            }

            g2.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);
            g2.setColor(getForeground());
            FontMetrics fm = g2.getFontMetrics();
            int x = (getWidth() - fm.stringWidth(getText())) / 2;
            int y = (getHeight() + fm.getAscent() - fm.getDescent()) / 2;
            g2.drawString(getText(), x, y);
            g2.dispose();
        }

        @Override
        protected void paintBorder(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground().darker());
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, radius, radius);
            g2.dispose();
        }
    }

    private static class RoundedInputPanel extends JPanel {
        private final int radius;
        private final Color borderColor;

        public RoundedInputPanel(int radius, Color borderColor) {
            super();
            this.radius = radius;
            this.borderColor = borderColor;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setClip(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), radius, radius));
            g2.setColor(Color.WHITE);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);
            g2.setColor(borderColor);
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, radius, radius);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    private JPanel createLabeledFieldPanel(String placeholder, String iconPath, JTextField field, int width, int height) {
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);

        JPanel inputPanel = new RoundedInputPanel(24, new Color(36, 207, 215));
        inputPanel.setLayout(new BorderLayout(8, 0));
        inputPanel.setOpaque(false);
        inputPanel.setPreferredSize(new Dimension(width, height));
        inputPanel.setMinimumSize(new Dimension(width, height));

        JLabel iconLabel = new JLabel();
        ImageIcon icon = loadIcon(iconPath, 24, 24);
        if (icon != null) {
            iconLabel.setIcon(icon);
            iconLabel.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
        }
        inputPanel.add(iconLabel, BorderLayout.WEST);

        field.setPreferredSize(new Dimension(width - 60, height - 16));
        field.setBorder(BorderFactory.createEmptyBorder(height / 4 - 2, 8, height / 4 - 2, 8));
        field.setOpaque(false);
        field.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        if (field.getText() == null || field.getText().trim().isEmpty()) {
            field.setText(placeholder);
            field.setForeground(new Color(150, 150, 150));
        } else {
            field.setForeground(new Color(30, 40, 50));
        }
        field.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (field.getText().equals(placeholder)) {
                    field.setText("");
                    field.setForeground(new Color(30, 40, 50));
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (field.getText().isEmpty()) {
                    field.setText(placeholder);
                    field.setForeground(new Color(150, 150, 150));
                }
            }
        });
        inputPanel.add(field, BorderLayout.CENTER);

        wrapper.add(inputPanel, BorderLayout.CENTER);
        return wrapper;
    }

    private JPanel createLabeledComboPanel(String placeholder, String iconPath, JComboBox<?> combo, int width, int height) {
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);

        JPanel inputPanel = new RoundedInputPanel(24, new Color(36, 207, 215));
        inputPanel.setLayout(new BorderLayout(8, 0));
        inputPanel.setOpaque(false);
        inputPanel.setPreferredSize(new Dimension(width, height));
        inputPanel.setMinimumSize(new Dimension(width, height));

        JLabel iconLabel = new JLabel();
        ImageIcon icon = loadIcon(iconPath, 24, 24);
        if (icon != null) {
            iconLabel.setIcon(icon);
            iconLabel.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
        }
        inputPanel.add(iconLabel, BorderLayout.WEST);

        combo.setOpaque(false);
        combo.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        combo.setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
        inputPanel.add(combo, BorderLayout.CENTER);

        wrapper.add(inputPanel, BorderLayout.CENTER);
        return wrapper;
    }

    private JPanel createLabeledComponentPanel(String placeholder, String iconPath, JComponent component) {
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);

        JPanel inputPanel = new RoundedInputPanel(24, new Color(36, 207, 215));
        inputPanel.setLayout(new BorderLayout(8, 0));
        inputPanel.setOpaque(false);
        inputPanel.setPreferredSize(new Dimension(300, 50));
        inputPanel.setMinimumSize(new Dimension(300, 50));

        JLabel iconLabel = new JLabel();
        ImageIcon icon = loadIcon(iconPath, 24, 24);
        if (icon != null) {
            iconLabel.setIcon(icon);
            iconLabel.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
        }
        inputPanel.add(iconLabel, BorderLayout.WEST);

        component.setPreferredSize(new Dimension(300 - 60, 50 - 16));
        component.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        component.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        inputPanel.add(component, BorderLayout.CENTER);

        wrapper.add(inputPanel, BorderLayout.CENTER);
        return wrapper;
    }

    // Classes auxiliares para a tabela
    private static class ButtonRenderer extends JPanel implements javax.swing.table.TableCellRenderer {
        private JButton btnVisualizar = new RoundedButton("Visualizar", 20);
        private JButton btnEditar = new RoundedButton("Editar", 20);
        private JButton btnDeletar = new RoundedButton("Deletar", 20);

        public ButtonRenderer() {
            setLayout(new FlowLayout(FlowLayout.CENTER, 3, 2));
            setOpaque(true);

            btnVisualizar.setFont(new Font("Segoe UI", Font.PLAIN, 10));
            btnVisualizar.setBackground(new Color(0, 123, 255));
            btnVisualizar.setForeground(Color.WHITE);
            btnVisualizar.setBorderPainted(false);
            btnVisualizar.setFocusPainted(false);
            btnVisualizar.setPreferredSize(new Dimension(65, 24));
            btnVisualizar.setMargin(new Insets(2, 6, 2, 6));

            btnEditar.setFont(new Font("Segoe UI", Font.PLAIN, 10));
            btnEditar.setBackground(new Color(255, 193, 7));
            btnEditar.setForeground(Color.WHITE);
            btnEditar.setBorderPainted(false);
            btnEditar.setFocusPainted(false);
            btnEditar.setPreferredSize(new Dimension(55, 24));
            btnEditar.setMargin(new Insets(2, 6, 2, 6));

            btnDeletar.setFont(new Font("Segoe UI", Font.PLAIN, 10));
            btnDeletar.setBackground(new Color(220, 53, 69));
            btnDeletar.setForeground(Color.WHITE);
            btnDeletar.setBorderPainted(false);
            btnDeletar.setFocusPainted(false);
            btnDeletar.setPreferredSize(new Dimension(55, 24));
            btnDeletar.setMargin(new Insets(2, 6, 2, 6));

            add(btnVisualizar);
            add(btnEditar);
            add(btnDeletar);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            if (isSelected) {
                setBackground(table.getSelectionBackground());
            } else {
                setBackground(Color.WHITE);
            }
            return this;
        }
    }

    private static class ButtonEditor extends DefaultCellEditor {
        private JPanel panel;
        private JButton btnVisualizar;
        private JButton btnEditar;
        private JButton btnDeletar;
        private JTable table;
        private int currentRow;
        private Consumer<Integer> onDelete;
        private Consumer<Integer> onView;
        private Consumer<Integer> onEdit;

        public ButtonEditor(JCheckBox checkBox, JTable table, Consumer<Integer> onDelete) {
            this(checkBox, table, onDelete, null, null);
        }

        public ButtonEditor(JCheckBox checkBox, JTable table, Consumer<Integer> onDelete, Consumer<Integer> onView) {
            this(checkBox, table, onDelete, onView, null);
        }

        public ButtonEditor(JCheckBox checkBox, JTable table, Consumer<Integer> onDelete, Consumer<Integer> onView, Consumer<Integer> onEdit) {
            super(checkBox);
            this.table = table;
            this.onDelete = onDelete;
            this.onView = onView;
            this.onEdit = onEdit;
            this.panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 0));

            btnVisualizar = new RoundedButton("Visualizar", 20);
            btnVisualizar.setFont(new Font("Segoe UI", Font.PLAIN, 10));
            btnVisualizar.setBackground(new Color(0, 123, 255));
            btnVisualizar.setForeground(Color.WHITE);
            btnVisualizar.setBorderPainted(false);
            btnVisualizar.setFocusPainted(false);
            btnVisualizar.setPreferredSize(new Dimension(65, 26));
            btnVisualizar.setMargin(new Insets(2, 8, 2, 8));
            btnVisualizar.addActionListener(e -> {
                if (currentRow >= 0 && onView != null) {
                    onView.accept(currentRow);
                } else if (currentRow >= 0) {
                    String nome = table.getValueAt(currentRow, 1).toString();
                    String numero = table.getValueAt(currentRow, 2).toString();
                    String curso = table.getValueAt(currentRow, 3).toString();
                    String departamento = table.getValueAt(currentRow, 4).toString();
                    String contacto = table.getValueAt(currentRow, 5).toString();
                    JOptionPane.showMessageDialog(table,
                            "Nome: " + nome + "\nNúmero: " + numero + "\nCurso: " + curso + "\nDepartamento: " + departamento + "\nContacto: " + contacto,
                            "Detalhes do Estudante", JOptionPane.INFORMATION_MESSAGE);
                }
                fireEditingStopped();
            });

            btnEditar = new RoundedButton("Editar", 20);
            btnEditar.setFont(new Font("Segoe UI", Font.PLAIN, 10));
            btnEditar.setBackground(new Color(255, 193, 7));
            btnEditar.setForeground(Color.WHITE);
            btnEditar.setBorderPainted(false);
            btnEditar.setFocusPainted(false);
            btnEditar.setPreferredSize(new Dimension(55, 26));
            btnEditar.setMargin(new Insets(2, 8, 2, 8));
            btnEditar.addActionListener(e -> {
                if (currentRow >= 0 && onEdit != null) {
                    onEdit.accept(currentRow);
                }
                fireEditingStopped();
            });

            btnDeletar = new RoundedButton("Deletar", 20);
            btnDeletar.setFont(new Font("Segoe UI", Font.PLAIN, 10));
            btnDeletar.setBackground(new Color(220, 53, 69));
            btnDeletar.setForeground(Color.WHITE);
            btnDeletar.setBorderPainted(false);
            btnDeletar.setFocusPainted(false);
            btnDeletar.setPreferredSize(new Dimension(55, 26));
            btnDeletar.setMargin(new Insets(2, 8, 2, 8));
            btnDeletar.addActionListener(e -> {
                if (currentRow >= 0 && onDelete != null) {
                    onDelete.accept(currentRow);
                }
                fireEditingStopped();
            });

            panel.add(btnVisualizar);
            panel.add(btnEditar);
            panel.add(btnDeletar);
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            this.currentRow = row;
            return panel;
        }

        @Override
        public Object getCellEditorValue() {
            return "Ações";
        }
    }

    private static class DigitOnlyFilter extends DocumentFilter {
        @Override
        public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
            if (string != null && string.matches("\\d+")) {
                super.insertString(fb, offset, string, attr);
            }
        }

        @Override
        public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
            if (text == null || text.matches("\\d*")) {
                super.replace(fb, offset, length, text, attrs);
            }
        }
    }

    private static class LetterOnlyFilter extends DocumentFilter {
        @Override
        public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
            if (string != null && string.matches("[\\p{L} ]+")) {
                super.insertString(fb, offset, string, attr);
            }
        }

        @Override
        public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
            if (text == null || text.matches("[\\p{L} ]*")) {
                super.replace(fb, offset, length, text, attrs);
            }
        }
    }
}
